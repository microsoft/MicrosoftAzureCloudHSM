# Copyright (C) Microsoft. All rights reserved.

from __future__ import annotations
import sys
from typing import Dict, List, Any, Iterator, Tuple
import argparse
from pathlib import Path
import json
import re

from constants import __version__, CORRELATION_ID_REGEX
from tracer import GREEN, RED, RESET, YELLOW, Logger, strip_ansi

# Certificate and signature records are batch metadata, not audit entries.
EXCLUDED_OPERATION_NAMES = frozenset(
    {
        "BATCH_BINARY_SIGNATURE",
        "BATCH_HSM_OWNER_AUTH_CERT",
        "BATCH_PARTITION_IDENTITY_CERT",
        "BATCH_HSM_MANUFACTURER_ROOT_CERT",
        "BATCH_HSM_DEVICE_CERT",
    }
)

REQUIRED_PROPERTIES_IN_AUDIT_LOG = (
    "TimeGenerated",
    "SequenceNumber",
    "OperationName",
    "OperationVersion",
    "Opcode",
    "ResultType",
    "ResultDescription",
    "CommandType",
    "AuditLogType",
    "UserID",
    "RebootCounter",
    "SessionHandle",
    "SessionType",
    "BinaryLogData",
    "AdditionalInfo",
)

# Lowercased for lookup, since _get_property matches property names case-insensitively.
_REQUIRED_PROPERTY_NAMES = frozenset(name.lower() for name in REQUIRED_PROPERTIES_IN_AUDIT_LOG)

# Distinguishes "property absent" from "property present and set to null" 
_MISSING = object()

def _get_property(record: Dict[str, Any], property_name: str) -> Any:
    """Look up a property, ignoring case"""
    if property_name in record:
        return record[property_name]

    lowered_property_name = property_name.lower()
    for key, value in record.items():
        if isinstance(key, str) and key.lower() == lowered_property_name:
            return value

    return _MISSING

def _property_text(record: Dict[str, Any], name: str) -> str:
    """Return a property rendered as text or an empty string when absent or null."""
    value = _get_property(record, name)

    if value is _MISSING or value is None:
        return ""

    return str(value)

def _read_actual_audit_logs(path: Path) -> List[Dict[str, Any]]:
    """Read the binary-to-text output, which holds one JSON record per line."""
    records: List[Dict[str, Any]] = []

    with path.open("r", encoding="utf-8-sig") as file_handle:
        for line_number, line in enumerate(file_handle, start=1):
            # Tolerate the trailing commas left when records are pasted into a list.   
            text = line.strip().rstrip(",")
            if not text:
                continue

            try:
                record = json.loads(text)
            except json.JSONDecodeError as error:
                raise ValueError(f"Failed to parse JSON on line {line_number}: {error}") from error

            if not isinstance(record, dict):
                raise ValueError(f"Expected a JSON object on line {line_number}")

            records.append(record)

    return records

def _read_expected_audit_logs(path: Path) -> List[Dict[str, Any]]:
    """Read the Log Analytics export and return its audit log records.

    Two export shapes are accepted: a JSON object holding a "Results" array, as
    produced by Azure PowerShell using `Invoke-AzOperationalInsightsQuery`, or
    a top-level array of records, as produced by the Azure CLI by running
    `az monitor log-analytics query`.
    """
    with path.open("r", encoding="utf-8-sig") as file_handle:
        try:
            document = json.load(file_handle)
        except json.JSONDecodeError as error:
            raise ValueError(f"Failed to parse JSON from expected audit log file: {error}") from error

        if isinstance(document, list):
            results = document
        else:
            results = _get_property(document, "Results") if isinstance(document, dict) else _MISSING

        if results is _MISSING or not isinstance(results, list):
            # Reject anything that is not a recognizable export, so the user gets a
            # clear message instead of the misleading "no logs for this correlation
            # id" failure that an empty record list would produce downstream.
            raise ValueError(
                f"Invalid JSON structure: expected either a top-level 'Results' array or a "
                f"top-level array of audit records in file {path}"
            )

    return [record for record in results if isinstance(record, dict)]


def _normalize(value: Any) -> Any:
    """Normalize known representation differences before comparing scalars."""
    return value.strip() if isinstance(value, str) else value

def _scalar_values_match(expected_value: Any, actual_value: Any) -> bool:
    """Compare two scalars, treating a change of type as a difference."""
    if expected_value is None or actual_value is None:
        return expected_value is None and actual_value is None

    # Both values must be the same data type; a difference in type alone counts as a mismatch.
    if type(expected_value) is not type(actual_value):
        return False

    # The audit log is evidence, so a difference in case is a real difference.
    if isinstance(expected_value, str):
        return expected_value == actual_value

    # Fallback for all other scalar types: compare for equality.
    return bool(expected_value == actual_value)

def _highlight(text: str) -> str:
    """Color text, but only when the output is a terminal."""
    # Escape sequences would be counted as width by the table formatter and would
    # corrupt the value for any consumer of redirected output, so color only on a terminal.
    if not sys.stdout.isatty():
        return text

    return f"{YELLOW}{text}{RESET}"

def _display(value: Any) -> str:
    """Render one cell value for the report."""
    # A blank cell reads better in the table than the word None.
    if value is None:
        return ""
    if isinstance(value, bool):
        return "True" if value else "False"
    # Nested objects are written without spaces so the cell stays on one line.
    if isinstance(value, (dict, list)):
        return json.dumps(value, separators=(",", ":"))

    return str(value)

def _format_table(columns: List[str], rows: List[Dict[str, Any]]) -> str:
    """Render rows as an auto-sized table, ignoring escape sequences when sizing."""
    widths = []
    for column in columns:
        width = len(column)
        for row in rows:
            # Color codes print as zero-width, so strip them before measuring or the column ends up too wide.
            width = max(width, len(strip_ansi(_display(row.get(column)))))
        widths.append(width)

    # Pad every cell out to its column width so the columns line up.
    def build_row(cells: List[str]) -> str:
        padded = []
        for index, cell in enumerate(cells):
            padding = widths[index] - len(strip_ansi(cell))
            padded.append(cell + " " * padding)

        # Trailing padding on the last cell serves no purpose, so drop it.
        return " ".join(padded).rstrip()

    # Column headers, then a row of dashes, then one row per record.
    lines = [
        build_row(columns),
        build_row(["-" * width for width in widths])
    ]

    lines.extend(build_row([_display(row.get(column)) for column in columns]) for row in rows)
    return "\n".join(lines)

def _find_missing_required_properties(expected: Dict[str, Any], actual: Dict[str, Any]) -> Iterator[Tuple[str, str]]:
    """Yield (property_name, missing_from) for each required property a record does not carry."""

    for required_property in REQUIRED_PROPERTIES_IN_AUDIT_LOG:
        expected_value = _get_property(expected, required_property)
        actual_value = _get_property(actual, required_property)

        if expected_value is not _MISSING and actual_value is not _MISSING:
            continue

        if expected_value is _MISSING and actual_value is _MISSING:
            yield (required_property, "expected and actual audit logs")
        elif expected_value is _MISSING:
            yield (required_property, "expected audit logs")
        else:
            yield (required_property, "actual audit logs")

def _compare_audit_log_properties(expected: Dict[str, Any], actual: Dict[str, Any], path: str = "") -> Iterator[Tuple[str, Any, Any]]:
    """Yield (property_path, expected_value, actual_value) for each differing property."""

    # The actual audit log defines the comparison contract. Properties that exist
    # only in the Log Analytics record, such as memberId, are intentionally ignored.
    for name, actual_value in actual.items():
        property_path = f"{path}.{name}" if path else name
        expected_value = _get_property(expected, name)

        if expected_value is _MISSING:
            # A missing required property is already reported by
            # _find_missing_required_properties, which names the side it is
            # missing from. Only nested and non-required properties are reported
            # here, so the two tables stay disjoint.
            if not path and name.lower() in _REQUIRED_PROPERTY_NAMES:
                continue

            yield (property_path, "missing", actual_value)
            continue

        # Log Analytics stores AdditionalInfo as JSON text, while the binary-to-text
        # output holds an object. Parse it before comparing its properties.
        if name.lower() == "additionalinfo" and isinstance(expected_value, str):
            if expected_value.strip():
                try:
                    expected_value = json.loads(expected_value)
                except json.JSONDecodeError as error:
                    raise ValueError(f"Invalid JSON in '{property_path}': {error}") from error
            else:
                expected_value = {}

        # Recurse into nested objects so expected-only nested properties are ignored.
        if isinstance(actual_value, dict):
            if not isinstance(expected_value, dict):
                yield (property_path, expected_value, actual_value)
                continue

            yield from _compare_audit_log_properties(expected_value, actual_value, property_path)
            continue

        normalized_expected_value = _normalize(expected_value)
        normalized_actual_value = _normalize(actual_value)

        if not _scalar_values_match(normalized_expected_value, normalized_actual_value):
            yield (property_path, normalized_expected_value, normalized_actual_value)

def run_compare_hsm_logs(args: argparse.Namespace) -> int:
    """CLI entrypoint for comparing a Log Analytics export with binary-to-text output."""
    expected_log_file: Path = Path(args.expected_log_file)
    actual_log_file: Path = Path(args.actual_log_file)
    correlation_id: str = args.correlation_id

    # Step 1: Validate the arguments before the log file is created, so a mistyped
    # path or a malformed correlation id fails immediately rather than leaving a
    # log behind for a run that never started.
    if not expected_log_file.exists():
        print(f"Expected log file does not exist: {expected_log_file}")
        return 1

    if expected_log_file.stat().st_size == 0:
        print(f"Expected log file is empty: {expected_log_file}")
        return 1

    if not actual_log_file.exists():
        print(f"Actual log file does not exist: {actual_log_file}")
        return 1

    if actual_log_file.stat().st_size == 0:
        print(f"Actual log file is empty: {actual_log_file}")
        return 1

    if not CORRELATION_ID_REGEX.match(correlation_id):
        print(f"Invalid correlation id format: {correlation_id}. Expected format is a UUID: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx")
        return 1

    logger = Logger("compare-hsm-audit-logs")
    logger.info(f"compare-hsm-audit-logs version: {__version__}")
    result_successful = True

    try:
        # Step 2: Echo the resolved arguments into the log file so the run is
        # self-documenting for support cases.
        options = {
            "expectedLogFile": args.expected_log_file,
            "actualLogFile": args.actual_log_file,
            "correlationId": args.correlation_id
        }

        logger.info(f"Parsed arguments: {json.dumps(options, indent=1)}")

        # Step 3: Load both sides. The actual records come from the binary-to-text
        # output and define the comparison contract; the Log Analytics export is
        # what they are compared against.
        actual_audit_logs = _read_actual_audit_logs(actual_log_file)
        expected_audit_logs = _read_expected_audit_logs(expected_log_file)

        # Step 4: Narrow the export down to this batch. An export usually spans many
        # correlation ids, and the certificate and signature rows it carries are batch
        # metadata with no counterpart in the converted output.
        expected_audit_logs_batch = [
            record
            for record in expected_audit_logs
            if _property_text(record, "CorrelationId").lower() == correlation_id.lower()
            and _property_text(record, "OperationName").upper() not in EXCLUDED_OPERATION_NAMES
        ]

        if not expected_audit_logs_batch:
            raise ValueError(f"No expected audit logs found for CorrelationId: {correlation_id}")

        # Step 5: Index the batch by sequence number, the only field that pairs a
        # converted record with its exported counterpart. A repeat means the export
        # holds duplicate rows, so no pairing can be trusted.
        expected_audit_logs_by_sequence_number: Dict[str, Dict[str, Any]] = {}
        for record in expected_audit_logs_batch:
            sequence_number = _property_text(record, "SequenceNumber")
            key = sequence_number.lower()

            if key in expected_audit_logs_by_sequence_number:
                raise ValueError(f"Duplicate expected audit log found for SequenceNumber: {sequence_number}")

            expected_audit_logs_by_sequence_number[key] = record

        # Step 6: Walk the converted records in file order. Each one either has no
        # counterpart in the export, or is compared against it property by property.
        matched_sequence_numbers = set()
        seen_sequence_numbers = set()
        logs_missing_from_expected: List[Dict[str, Any]] = []
        duplicate_actual_logs: List[Dict[str, Any]] = []
        missing_properties: List[Dict[str, Any]] = []
        differences: List[Dict[str, Any]] = []

        for actual_audit_log in actual_audit_logs:
            sequence_number = _property_text(actual_audit_log, "SequenceNumber")
            key = sequence_number.lower()

            # The first record for this sequence number was already compared, so the
            # repeat is recorded and skipped rather than compared a second time,
            # which would restate every difference it carries.
            if key in seen_sequence_numbers:
                duplicate_actual_logs.append(
                    {
                        "CorrelationId": correlation_id,
                        "SequenceNumber": _highlight(sequence_number),
                        "OperationName": _property_text(actual_audit_log, "OperationName")
                    }
                )

                continue

            seen_sequence_numbers.add(key)

            expected_audit_log = expected_audit_logs_by_sequence_number.get(key)
            if expected_audit_log is None:
                logs_missing_from_expected.append(
                    {
                        "CorrelationId": correlation_id,
                        "SequenceNumber": _highlight(sequence_number),
                        "OperationName": _property_text(actual_audit_log, "OperationName")
                    }
                )

                continue

            matched_sequence_numbers.add(key)

            for property_path, missing_from in _find_missing_required_properties(expected_audit_log, actual_audit_log):
                missing_properties.append(
                    {
                        "CorrelationId": correlation_id,
                        "SequenceNumber": _highlight(sequence_number),
                        "OperationName": _property_text(actual_audit_log, "OperationName"),
                        "Property": property_path,
                        "MissingFrom": missing_from
                    }
                )

            for property_path, expected_value, actual_value in _compare_audit_log_properties(expected_audit_log, actual_audit_log):
                differences.append(
                    {
                        "CorrelationId": correlation_id,
                        "SequenceNumber": _highlight(sequence_number),
                        "OperationName": _property_text(actual_audit_log, "OperationName"),
                        "Property": property_path,
                        "Expected": expected_value,
                        "Actual": actual_value
                    }
                )

        # Step 7: Whatever the walk never matched is present in Log Analytics but
        # absent from the converted output.
        logs_missing_from_actual = [
            {
                "CorrelationId": correlation_id,
                "SequenceNumber": _highlight(_property_text(record, "SequenceNumber")),
                "OperationName": _property_text(record, "OperationName")
            }
            for record in expected_audit_logs_batch
            if _property_text(record, "SequenceNumber").lower() not in matched_sequence_numbers
        ]

        # Step 8: Report each category in its own table so a large batch stays readable.
        record_columns = ["CorrelationId", "SequenceNumber", "OperationName"]
        if logs_missing_from_expected:
            logger.error(
                f"{RED}Actual audit logs missing from expected audit logs:{RESET}\n"
                f"{_format_table(record_columns, logs_missing_from_expected)}"
            )

        if logs_missing_from_actual:
            logger.error(
                f"{RED}Expected audit logs missing from actual audit logs:{RESET}\n"
                f"{_format_table(record_columns, logs_missing_from_actual)}"
            )

        if duplicate_actual_logs:
            logger.error(
                f"{RED}Duplicate actual audit logs:{RESET}\n"
                f"{_format_table(record_columns, duplicate_actual_logs)}"
            )

        if missing_properties:
            logger.error(
                f"{RED}Required properties missing from the audit logs:{RESET}\n"
                f"{_format_table(record_columns + ['Property', 'MissingFrom'], missing_properties)}"
            )

        if differences:
            logger.error(
                f"{RED}Differences between expected and actual audit logs:{RESET}\n"
                f"{_format_table(record_columns + ['Property', 'Expected', 'Actual'], differences)}"
            )

        # Step 9: Any populated category fails the comparison.
        if (
            logs_missing_from_expected
            or logs_missing_from_actual
            or duplicate_actual_logs
            or missing_properties
            or differences
        ):
            raise ValueError(f"Audit Log Comparison failed for CorrelationId: {correlation_id}")

        logger.info(
            f"{GREEN}All {len(expected_audit_logs_batch)} expected audit log(s) match the actual audit logs "
            f"for CorrelationId: {correlation_id}{RESET}"
        )

    except Exception as error:
        # Log the error and mark the result as unsuccessful
        logger.error(f"{RED}Error comparing audit logs: {error}{RESET}")
        result_successful = False
    finally:
        # Always flush and close the log file, even on failure, so the customer
        # has a complete record of the verification attempt.
        logger.close()

    # Non-zero exit code lets shell scripts and CI pipelines detect failures.
    return 0 if result_successful else 1

# SIG # Begin Windows Authenticode signature block
# MIInNwYJKoZIhvcNAQcCoIInKDCCJyQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCayb/3MFIwzpgE
# O7FIDMwyPage62FZ0t3nM453MH0c0aCCDMkwggYEMIID7KADAgECAhMzAAACHPrN
# xZvoL37EAAAAAAIcMA0GCSqGSIb3DQEBCwUAMFcxCzAJBgNVBAYTAlVTMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBD
# b2RlIFNpZ25pbmcgUENBIDIwMjQwHhcNMjYwNDE2MTg1OTQxWhcNMjcwNDE1MTg1
# OTQxWjB0MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYD
# VQQDExVNaWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IB
# DwAwggEKAoIBAQDVsZfgOKmM31HPfoWOoNEiw0SlCiIxUMC0I9NMWbucKOw/e9lP
# oAoehQVu6SG65V4EPzrYsnBnFPNoi4/HoOdjhz1qkrEt4I6tEcxXU6oOeY9zGveC
# /3iBeuhLYxM3M/PkcUoebF+Nednm8OkdSPoDu8imViHPQq/8CQUu0WRR4rE+dMRf
# rpVqfmNi2qWCX94T4MsepijGVkwE//tJg0ryAiYdHT34LSnlG/RSBZmQRGWZ5g8j
# qnKjRParSqMft1gvjuUTVgtWNZfgcLFSK5Wa0myrq8OPcgTGGsRgun+tnSS+IxDT
# xVsAPH1OzvPjwomguByhUe/OcvUN0D5Wmp7xAgMBAAGjggGqMIIBpjAOBgNVHQ8B
# Af8EBAMCB4AwHwYDVR0lBBgwFgYKKwYBBAGCN0wIAQYIKwYBBQUHAwMwHQYDVR0O
# BBYEFNoH7a2YDjOSwpkp6DHcmUS7J+0yMFQGA1UdEQRNMEukSTBHMS0wKwYDVQQL
# EyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxFjAUBgNVBAUT
# DTIzMDAxMis1MDc1NjkwHwYDVR0jBBgwFoAUf1k/VCHarU/vBeXmo9ctBpQSCDEw
# YAYDVR0fBFkwVzBVoFOgUYZPaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9w
# cy9jcmwvTWljcm9zb2Z0JTIwQ29kZSUyMFNpZ25pbmclMjBQQ0ElMjAyMDI0LmNy
# bDBtBggrBgEFBQcBAQRhMF8wXQYIKwYBBQUHMAKGUWh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwQ29kZSUyMFNpZ25pbmcl
# MjBQQ0ElMjAyMDI0LmNydDAMBgNVHRMBAf8EAjAAMA0GCSqGSIb3DQEBCwUAA4IC
# AQAUnEqhaRXe0T3hIJjvdQErEkrA/7bByjn6t5IArODkkRjzkYwtKMc2yYj2quaN
# rLutWw2YZcngKPy1b71YyDJQTy4NDRwaSh9Tw5thrk3NmcPrAHia5vtcBJ1CgtKK
# 7mQbIcQ22d/N3813ayCDDFewu1+jsZmX+r/aTEqaOM4TVxVtRSkuCy8nAXKuChOK
# Li/zA4XuH8iEYqIsj2YoNaeSxVmeGiERXpKdo3dDmYi0kO5w2D8VS4c3+9h6gElY
# BaAAg/dYErBg27qT3vv0zRDJhJufvCNylA8S7/+8H5E/PV5cng6na9VV/w9OV3qu
# uND6zdGa2EX38Glp50F9AIQk3p2xXmcvorDeM4XJ7UlWYBi6g80J1SSOQnInCYFE
# msfUNn3+1AaTJKSJL83quKArTac2pKhu0Yzzzrzo6HrsRiQKzpnRBb1/dMa6P3hz
# 75XbMRBctNsFhZC07WCmjExdLg2eHW5uV0TY8D5+6wozJf7vF3+WHkYPO85Z+BC6
# U4FkNbYNycZ9cE4j1tXRdyDCfml6c0HWPHjNVDObrv9lKt3qUqFpX38VCqVCyNOO
# 1UcXfQiVjJw32U2WUKZjt/neJKHEBsm9kFsLuWzkQ53+qcaSaytmsCnk2gOglrlD
# 5d3kKyvvAw+rzm0lT8K38P6PLxfZQHhu4W8dV7Av8N2ZmDCCBr0wggSloAMCAQIC
# EzMAAAA5O7Y3Gb8GHWcAAAAAADkwDQYJKoZIhvcNAQEMBQAwgYgxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBS
# b290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDExMB4XDTI0MDgwODIwNTQxOFoX
# DTM2MDMyMjIyMTMwNFowVzELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EgMjAyNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANgBnB7jOMeq
# lRYHNa265v4IY9fH8TKhemHfPINe1gpLaV3dhg324WwH06LcHbpnsBukCDNitryo
# 0dtS/EW6I/yEL/bLSY8hKpbfQuWusBPr9qazYcDxCW/qnjb5JsI1s8bNOg3bVATv
# QVL4tcf03aTycsz8QeCdM0l/yHRObJ9QqazM1r6VPEOJ7LL+uEEb73w6QCuhs89a
# 1uv1zerOYMnsneRRwCbpyW11IcggU0cRKDDq1pjVJzIbIF6+oiXXbReOsgeI8zu1
# FyQfK0fVkaya8SmVHQ/tOf23mZ4W9k0Ri22QW9p3UgSC5OUDktKxxcCmGL6tXLfO
# GSWHIIV4YrTJTT6PNty5REojHJuZHArkF9VnHTERWoTjAzfI3kP+5b4alUdhgAZ7
# ttOu1bVnXfHaqPYl2rPs20ji03LOVWsh/radgE17es5hL+t6lV0eVHrVhsssROWJ
# uz2MXMCt7iw7lFPG9LXKGjsmonn2gotGdHIuEg5JnJMJVmixd5LRlkmgYRZKzhxS
# CwyoGIq0PhaA7Y+VPct5pCHkijcIIDm0nlkK+0KyepolcqGm0T/GYQRMhHJlGOOm
# VQop36wUVUYklUy++vDWeEgEo4s7hxN6mIbf2MSIQ/iIfMZgJxC69oukMUXCrOC3
# SkE/xIkgpfl22MM1itkZ35nNXkMolU1lAgMBAAGjggFOMIIBSjAOBgNVHQ8BAf8E
# BAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFH9ZP1Qh2q1P7wXl5qPX
# LQaUEggxMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAUci06AjGQQ7kUBU7h6qfHMdEjiTQwWgYDVR0fBFMwUTBP
# oE2gS4ZJaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljUm9vQ2VyQXV0MjAxMV8yMDExXzAzXzIyLmNybDBeBggrBgEFBQcBAQRSMFAw
# TgYIKwYBBQUHMAKGQmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMv
# TWljUm9vQ2VyQXV0MjAxMV8yMDExXzAzXzIyLmNydDANBgkqhkiG9w0BAQwFAAOC
# AgEAFJQfOChP7onn6fLIMKrSlN1WYKwDFgAddymOUO3FrM8d7B/W/iQ6DxXsDn7D
# 5W4wMwYeLystcEqfkjz4NURRgazyMu5yRzQh4LqjA4tStTcJh1opExo7nn5PuPBY
# nbu0+THSuVHTe0VTTPVhily/piFrDo3axQ9P4C+Ol5yet+2gTfekICS5xS+cYfSI
# vgn0JksVBVMYVI5QFu/qhnLhsEFEUzG8fvv0hjgkO+lkpV9ty6GkN4vdnd7ya6Q6
# aR9y34aiM1qmxaxBi6OUnyNl6fkuun/diTFnYDLTppOkr/mg5WSfCiDVMNCxtj4w
# PKC5OmHm1DQIt/MNokbbH3UGsFP1QbzsLocuSqLCvH09Io3fDPTmscR9Y75G4qX7
# RTX8AdBPo0I6OEojf39zuFZt0qOHm65YWQE69cZM2ueE1MB05dNNgHK9gTE7zKvK
# /fg8B2qjW88MT/WF5V5uvZGtqa9FSL2RazArA+rDPuf6JGYz4HpgMZHB4S6szWSK
# YBv0VisCzfxgeU+dquXW9bd0auYlOB58DPcOYKdc3Se94g+xL4pcEhbB54JOgAkw
# YTu/9dLeH2pDqeJZAABVDWRQCaXfO5LgyKwKCLYXpigrZYCjUSBcr+Ve8PFWMhVT
# Ql0v4q8J/AUmQN5W4n101cY2L4A7GTQG1h32HHAvfQESWP0xghnEMIIZwAIBATBu
# MFcxCzAJBgNVBAYTAlVTMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# KDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMjQCEzMAAAIc
# +s3Fm+gvfsQAAAAAAhwwDQYJYIZIAWUDBAIBBQCggZAwGQYJKoZIhvcNAQkDMQwG
# CisGAQQBgjcCAQQwLwYJKoZIhvcNAQkEMSIEIJHw7uJqMHNP0xc0z5ab1fAWOZSD
# IptVzLqHLNrGW66PMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8AcwBv
# AGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAE
# ggEAf+D2EqZCIwqAkKcIaWEhD7/+QMyfl870bTTnG9kfVlBMh1kK3/X3+8iUD8pM
# 2EI4mA+rz0xjLaxPoxnJvS1SPID/le1T8Ms3WE6PknXkT4O1LuCtOcN809SBu/NY
# fIbyA83db489f0hRFQYf6yDB3i18ASnjtz3ka/nBZ29zD9pIxLQ/ae8wklsjMwLc
# hv2X7p6yjLsGM57v8oB7MyDbfVqmL9ZH6OdGZEKZPwZVP1RWgt4ZMg+BPg2MjyXL
# BMn3EOFnb5LCI2r88NzNDDmjtWuOpI9JCiIzCDcQtumyUqPTPWjhKMi63NSW9jnZ
# poQH7DYGJ1+mcxQ6a5CYhQ/Kj6GCF5QwgheQBgorBgEEAYI3AwMBMYIXgDCCF3wG
# CSqGSIb3DQEHAqCCF20wghdpAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsqhkiG
# 9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQC
# AQUABCAI69H7jNSWl0R4CHhacKTGCh8hlD1uwL4EOVhswJv6WQIGaqk5Y1isGBMy
# MDI2MTAxMzAyNDIyNS4zMjdaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmlj
# YSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046QTQwMC0wNUUw
# LUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WgghHq
# MIIHIDCCBQigAwIBAgITMwAAAijwpYfX88geQAABAAACKDANBgkqhkiG9w0BAQsF
# ADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yNjAyMTkxOTQwMDZa
# Fw0yNzA1MTcxOTQwMDZaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScw
# JQYDVQQLEx5uU2hpZWxkIFRTUyBFU046QTQwMC0wNUUwLUQ5NDcxJTAjBgNVBAMT
# HE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEBAQUA
# A4ICDwAwggIKAoICAQCujvbk/sqcCSReZaJfCuf1NwRcc7XknhE6wkLofkNj1mxE
# Ag35qy2xcFjgjartVvA09W8QHcpyMqVSXOTxNHJsmk0qP2CDLvUAulWg7aS5oBOR
# pEX1oz3n0R2nPqeH0IHK1zJxjxaHW21AbuZ0Z+wM3WYNzkBlcHmVe03ZG7rlk28h
# 72r5P5ME8FGpFmYW5Hl7psKbgLEfrYAitpttsb+sZsBUI+hMKl4uLJYotKyZv1ew
# OIinBfRU8QosivjofaBezUf9NdV+iGrWh321WnSsK3A/Jl6GLtbSWXcJWULgbxuq
# nobPK+YlB3174TMWTgX4YWjG7o0Otz/pjHNCKBbB788dynhLdGY6B08E9+4SGrRp
# sty4iJHOydHCA5M4i5yYRwsdut+gmvxIpT8yNXJcjJCg0vO8mv/nFY9Wytv2qmCt
# CFFivGUWqU20/sUeRooQZGiQOJQn095Cj3isIsvRP8KU7hN/EDI8HVsb/NPzMFLv
# RznrRnj0TOnDiOTUcnYwmk+XfoS1owskcCCCwHnbC00D58z83y7K5ZJB745hcn4C
# E2nR3e6RGsr42y5qtt6Mdz/s7MTnDS2UmVHWX1X/HZe3UlX8gj/t63L50xIPqkRC
# BEdM1ADNUaSfo9OQiKb/bj1diZCGTfEDUBBLop1mhkwIF82faplV2busZ+U4kQID
# AQABo4IBSTCCAUUwHQYDVR0OBBYEFKrJpYz48tzouvVkBVthASFpQ93DMB8GA1Ud
# IwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCGTmh0
# dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUyMFRp
# bWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4wXAYI
# KwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMv
# TWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwGA1Ud
# EwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQDAgeA
# MA0GCSqGSIb3DQEBCwUAA4ICAQCQ6NfLmrRahgVtgWg383GaS07fHyod6bhcUONt
# 2tet+6BaNuH0r7ABkVHheOpxBdrUrOEYVEaIii9dK3cuZLNmp1iUAx/VbmOZYl7x
# z+tNrjCWqrg1jQmq0oRB8iE4QJpwNhGP67oY5huYIU0D4lhDoahqfgKJn/0Bk+9U
# KDPw5XlUYmreFmJlj9YQzcPPep8MxBXxh/Y5I7vQeRaW5SjtiLQOLRk3ggvraDs5
# Sf49MJV6/BwxXC2rvUfEFX6SUDooqKIE9NgVIRq0RZu7Ot0i0Is+HvPP0hB6KwOx
# Mg1SWKOfTtFpWpdo8MJvgKCHkPpXEzgprP+pyIHuO7gVRlSTsbYBFLh2yId/itM4
# uYL0R+2SSBBTpSSRthrGuEmElI5BCHMxzMg/oqHSPwZAIAkM2C4xxi0St7qMuA+m
# +ZzFYkfoF41QoSJn+HjqhqWYQ0m/SO9/KnJRJJUwMd5TiMnjZ+E/DJiUry5udiWy
# Qpvfj2hQFI0djhahoAXDazeEciLF2uEnTur9UfjcwOun/oMY+ULftnOi2jKLMrre
# V097akzz/JxpnDgYJU/tgU7fQflg7IqiL9+0276+joQHo21mVeY5YD8Kh/kUaY6J
# m/OTM88G7evTz/qnRumxovTjMStvpbAHNRhmSTdIPTV32CyuxDKS/V5a5iwA+f9V
# iBo+wjCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcN
# AQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAw
# BgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEw
# MB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk
# 4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9c
# T8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWG
# UNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6Gnsz
# rYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2
# LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLV
# wIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTd
# EonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0
# gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFph
# AXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJ
# YfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXb
# GjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJ
# KwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnP
# EP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMw
# UQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggr
# BgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYw
# DwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoY
# xDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0B
# AQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U5
# 18JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgAD
# sAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo
# 32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZ
# iefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZK
# PmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RI
# LLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgk
# ujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9
# af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzba
# ukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/
# OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNNMIIC
# NQIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEnMCUG
# A1UECxMeblNoaWVsZCBUU1MgRVNOOkE0MDAtMDVFMC1EOTQ3MSUwIwYDVQQDExxN
# aWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQB1rbmF
# kzS7qAK1Oav08AUnhbNIUqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA7nf0zzAiGA8yMDI2MTAxMzAwMDc0M1oY
# DzIwMjYxMDE0MDAwNzQzWjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDud/TPAgEA
# MAcCAQACAhYWMAcCAQACAhI5MAoCBQDueUZPAgEAMDYGCisGAQQBhFkKBAIxKDAm
# MAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcN
# AQELBQADggEBAH4aDkdrXRDLnxtjgvjtqakhKvpQ5nTQnF07CcSDFDS1MX53nRLk
# 7NqNSpLz/0YU20dttcV+yL98HBas11vfHkmfG5w8XIuxCyTqoUCpmISPZ6aNftWR
# l1jY+gtYdT3yhICRZZEL5pH2ukHnLjETZA8wVcmF7RKtr0yU0dArt/taZz6KCoDf
# 2sku2rpS/m7ea1QaupRFPo9byoq1slTCDqJEnVbEoULqdbDSbaM1jLUsYERF3gwd
# RAOqXk057meiOMpY3GoOmq1yh2BzC8OaEjb5Ln0CfxNc2YnBP+e2QHKFjlU+TZdc
# QntDPvlrrAyOsRniRYeGclLzzAH2NOI9FAkxggQNMIIECQIBATCBkzB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAijwpYfX88geQAABAAACKDANBglg
# hkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqG
# SIb3DQEJBDEiBCAWp9Kowk7gL7/xaGh2JZN1zY45A/hKbuR62iHtkzQFpzCB+gYL
# KoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIFWxikZRYGNf4oEVZK1eT45H+3GQ3/qx
# V75VwuBt+iLXMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAAIo8KWH1/PIHkAAAQAAAigwIgQg0WOMA8FZzduHJsVc3vMWCR1O2uVen/Fm
# R9+HUlyQU98wDQYJKoZIhvcNAQELBQAEggIAjMlZJojRm5Ar1QHYeWSpOinFV3ie
# dZG4KYJNg0AmHRd7KMUTR+ymZ+Ba52QOE5A9phnCOalKtrxrL9UD7ae1LjB/2DEK
# WJ/gGkQOYVmSFMpYclKS95RcU9t4crcZpIii4WEPt20OCv5bK/ltHSDKC6px3qDa
# mL/3Z+MaLoCxI+LwTnz3KJk25fRmUIcBOgphQzWtxwlsbBQZy+/6XpYhPzk3Q8Do
# ZKchYvZU2fFGKzUe0B0uqIT7mfQZJjSDkuqmM9Ie1Qt9B71zgaTZ6jnD7QZRVGWh
# I3dT68R4JRa4iBEORUuOP4ckBOEyDjH/D7qk4JKYXrwnkoh3JdMXaYoBvt4IrCDg
# Jo+O0TSERHu3BPSlTSWb5+rKQaN3h2PrIbaAmSEGInarIhLpoUZ+xoBMtGZjEA4p
# aB3pbP4TMrQGu8E6sURZXen3hqWvfnFpLUg+orlUgtjFOL9AuBdAusDjl3X99fBF
# EXME7q+a0sXO7kykcVKXIyQkIXlYDEZg9fCq99wA9VIj+nrwxmzeHqKSOhiHmrck
# 001f5qhVBlawC0gqXOE5qocWEOuIEBLcbraldq3/CNP/i703pYxy63fkNLzP1Ul4
# DgnDPkilP0fHle6DN/DdjfugmYZnANWVTz+2JCb7Sp4Hl/fBlN3JfxUSbZs6pRDK
# yl15kPR/yMNR/Us=
# SIG # End Windows Authenticode signature block