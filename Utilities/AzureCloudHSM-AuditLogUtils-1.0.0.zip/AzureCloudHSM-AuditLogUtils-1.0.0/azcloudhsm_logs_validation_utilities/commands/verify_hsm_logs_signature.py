# Copyright (C) Microsoft. All rights reserved.

from __future__ import annotations

import argparse
import base64
import hashlib
from __init__ import __version__
import json
from datetime import datetime, timezone
from pathlib import Path

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

from constants import (
    AUDIT_LOG_RECORD_SIZE,
    DROP_COUNT_LENGTH,
    PUBKEY_HASH_PREFIX_LENGTH,
    RSA_SIGNATURE_LENGTH,
    SHA256_HASH_LENGTH,
    SIGNATURE_FILE_SIZE,
)
from tracer import GREEN, RED, RESET, Logger
from typing import Dict

def _print_cert_details(logger: Logger, cert: x509.Certificate, cert_name: str) -> None:
    """Log human-readable details for a parsed X.509 certificate."""
    logger.info(f"Certificate details for {cert_name}:")
    logger.info(f"{cert_name} Certificate Subject: {cert.subject.rfc4514_string()}")
    try:
        san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName)
        logger.info(f"{cert_name} Certificate Subject Alternative Name: {san.value}")
    except x509.ExtensionNotFound:
        logger.info(f"{cert_name} Certificate Subject Alternative Name: ")
        
    logger.info(f"{cert_name} Certificate Issuer: {cert.issuer.rfc4514_string()}")
    valid_from = getattr(cert, "not_valid_before_utc", None) or cert.not_valid_before
    valid_to = getattr(cert, "not_valid_after_utc", None) or cert.not_valid_after
    logger.info(f"{cert_name} Certificate valid from: {valid_from}")
    logger.info(f"{cert_name} Certificate valid to: {valid_to}")
    logger.info(f"{cert_name} Certificate SHA-1 Thumbprint: {cert.fingerprint(hashes.SHA1()).hex()}") # CodeQL [SM02167] SHA-1 is used only to print certificate thumbprint for debugging purposes.
    logger.info(f"{cert_name} Certificate SHA-256 Thumbprint: {cert.fingerprint(hashes.SHA256()).hex()}")
    logger.info(f"{cert_name} Certificate has public key: {cert.public_key() is not None}")
    
    public_key_pem = cert.public_key().public_bytes(encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo).decode("utf-8")
    logger.info(f"{cert_name} Certificate Public Key:\n {public_key_pem}")


def run_verify_hsm_logs_signature(args: argparse.Namespace) -> int:
    """CLI entrypoint for verifying audit log .bin/.sign artifacts and certificate chain data."""
    logger = Logger("verify-audit-logs-signature")
    
    # Log CLI version
    logger.info(f"verify-audit-logs-signature version: {__version__}")
    result_successful = True
    try:
        # Step 1: Echo the resolved arguments into the log file so the run is
        # self-documenting for support cases.
        options = {
            "binaryFile": args.binary_file,
            "signatureFile": args.signature_file,
            "certFile": args.cert_file
        }
        logger.info(f"Parsed arguments: {json.dumps(options, indent=1)}")

        # Step 2: Validate that all three artifacts were supplied. Verification
        # is only meaningful when the .bin, .sign, and _certs.json files that
        # `get-signed-audit-log-batch` emitted together are all present.
        if not args.binary_file:
            logger.error(f"{RED}Error: -b or --binary-file argument is required.{RESET}")
            raise ValueError("Binary file path is required")

        if not args.signature_file:
            logger.error(f"{RED}Error: -s or --signature-file argument is required.{RESET}")
            raise ValueError("Signature file path is required")

        if not args.cert_file:
            logger.error(f"{RED}Error: -c or --cert-file argument is required.{RESET}")
            raise ValueError("Certificate file path is required")

        # Step 3: Confirm each artifact exists on disk and is non-empty before
        # reading it, so a mistyped path produces a clear message rather than a
        # confusing parse error further down.
        binary_path = Path(args.binary_file)
        signature_path = Path(args.signature_file)
        cert_path = Path(args.cert_file)

        if not binary_path.exists():
            logger.error(f"{RED}Error: File not found at path '{args.binary_file}'.{RESET}")
            raise ValueError(f"File not found at path '{args.binary_file}'")
        if not signature_path.exists():
            logger.error(f"{RED}Error: File not found at path '{args.signature_file}'.{RESET}")
            raise ValueError(f"File not found at path '{args.signature_file}'")
        if not cert_path.exists():
            logger.error(f"{RED}Error: File not found at path '{args.cert_file}'.{RESET}")
            raise ValueError(f"File not found at path '{args.cert_file}'")
        
        if binary_path.stat().st_size == 0:
            logger.error(f"{RED}Error: Binary file is empty.{RESET}")
            raise ValueError("Binary file is empty")
        if signature_path.stat().st_size == 0:
            logger.error(f"{RED}Error: Signature file is empty.{RESET}")
            raise ValueError("Signature file is empty")
        if cert_path.stat().st_size == 0:
            logger.error(f"{RED}Error: Certificate file is empty.{RESET}")
            raise ValueError("Certificate file is empty")

        # Step 4: Load the raw bytes of the batch and its signature, plus the
        # certificate document that was extracted from the original audit log.
        binary_data = binary_path.read_bytes()
        signature_data = signature_path.read_bytes()
        cert_json: Dict[str, object] = json.loads(cert_path.read_text(encoding="utf-8-sig"))

        # Step 5: Sanity-check the artifact sizes. A .bin whose length is not a
        # whole number of records, or a .sign that is not exactly the expected
        # length, means the wrong file was passed or the file was truncated.
        # Verify size of binary data is a multiple of 128 bytes (size of each audit log record)
        if len(binary_data) % AUDIT_LOG_RECORD_SIZE != 0:
            logger.error(
                f"{RED}Error: Binary file size is not a multiple of {AUDIT_LOG_RECORD_SIZE} bytes. "
                "Please ensure the correct binary file is provided."
                f"{RESET}"
            )
            raise ValueError(f"Binary file size is not a multiple of {AUDIT_LOG_RECORD_SIZE} bytes")

        # Verify size of signature data is 296 bytes (256 bytes for signature + 8 bytes for drop count + 32 bytes for hash)
        if len(signature_data) != SIGNATURE_FILE_SIZE:
            logger.error(
                f"{RED}Error: Signature file size is not {SIGNATURE_FILE_SIZE} bytes. Actual size: {len(signature_data)} bytes. "
                "Please ensure the correct signature file is provided."
                f"{RESET}"
            )
            raise ValueError(f"Signature file size is not {SIGNATURE_FILE_SIZE} bytes")
        
        # Step 6: Pull the two certificates out of the JSON document. Both must
        # be present and DER-encoded; the Partition certificate provides the
        # public key that signed the batch, and both public keys are hashed into
        # the signed payload (see the layout diagram below).
        partition_cert_base64 = cert_json.get("partition_cert_base64")
        partition_cert_format = cert_json.get("partition_cert_format")
        
        hsm_owner_auth_cert_base64 = cert_json.get("hsm_owner_auth_cert_base64")
        hsm_owner_auth_cert_format = cert_json.get("hsm_owner_auth_cert_format")
        
        if partition_cert_base64 is None:
            raise ValueError("Partition certificate DER data is missing")
        if partition_cert_format is None:
            raise ValueError("Partition certificate format is missing")
        
        if hsm_owner_auth_cert_base64 is None:
            raise ValueError("HSM Owner Auth certificate DER data is missing")
        if hsm_owner_auth_cert_format is None:
            raise ValueError("HSM Owner Auth certificate format is missing")

        if not (str(partition_cert_base64) != "" and str(partition_cert_format).lower() == "der"):
            raise ValueError("Partition certificate DER data is missing")
        if not (str(hsm_owner_auth_cert_base64) != "" and str(hsm_owner_auth_cert_format).lower() == "der"):
            raise ValueError("HSM Owner Auth certificate DER data is missing")

        # Step 7: Parse the DER bytes into X.509 objects. Under --debug, also log
        # their details (subject, issuer, validity window, thumbprints, public
        # key) so the customer can confirm the batch was signed by the HSM
        # partition they expect. This output is verbose, so it is suppressed on
        # a normal run.
        partition_cert = x509.load_der_x509_certificate(base64.b64decode(partition_cert_base64, validate=True), default_backend())
        hsm_owner_auth_cert = x509.load_der_x509_certificate(base64.b64decode(hsm_owner_auth_cert_base64, validate=True), default_backend())
        
        if args.debug:
            _print_cert_details(logger, partition_cert, "Partition")
            _print_cert_details(logger, hsm_owner_auth_cert, "HSM")

        # Step 8: Split the 296-byte .sign file into its three fixed-width
        # fields: the RSA signature, the count of log entries the HSM had to
        # drop, and the SHA-256 hash the HSM computed over the signed payload.
        signature_buffer = signature_data[0:RSA_SIGNATURE_LENGTH]
        drop_count_buffer = signature_data[RSA_SIGNATURE_LENGTH : RSA_SIGNATURE_LENGTH + DROP_COUNT_LENGTH]
        hash_buffer = signature_data[RSA_SIGNATURE_LENGTH + DROP_COUNT_LENGTH : SIGNATURE_FILE_SIZE]

        logger.info(f"Drop count from signature file: {int.from_bytes(drop_count_buffer, byteorder='big', signed=False)}")

        # Step 9: Re-derive the certificate public key fingerprints that the HSM
        # folded into the signed payload. Binding these into the signature is
        # what stops a valid batch from being replayed under a different
        # partition or HSM.
        # openssl i2d_PUBKEY_bio exports public key in DER format, which is a binary encoding of SubjectPublicKeyInfo
        partition_pub_key_der = partition_cert.public_key().public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        hsm_owner_auth_pub_key_der = hsm_owner_auth_cert.public_key().public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        # Compute SHA-1 hashes and take first 8 bytes 
        partition_pub_hash_prefix = hashlib.sha1(partition_pub_key_der).digest()[:PUBKEY_HASH_PREFIX_LENGTH] # CodeQL [SM02167] SHA-1 is used only to compute the first 8 bytes of the SHA-1 hash of the public key for signature verification purposes.
        hsm_pub_hash_prefix = hashlib.sha1(hsm_owner_auth_pub_key_der).digest()[:PUBKEY_HASH_PREFIX_LENGTH]  # CodeQL [SM02167] SHA-1 is used only to compute the first 8 bytes of the SHA-1 hash of the public key for signature verification purposes.

        # Actual signature is over the contents of the audit log entries for the batch concatenated
        # with the first 8 bytes of the SHA1 hash of the Partition's certificate public key, 
        # the first 8 bytes of the SHA1 hash of the HSM's certificate public key, and the number of dropped
        # log entries as a 64 bit integer.
        # The log signature is a RS256 signature by the partition certificate (PAC) on the SHA-2 256 hash of the following data 
        # ------------------------------------------------------------------------- 
        # | Binary Logs     | HASH(PCertPub)* | HASH(HCertPub)* | droppedLogCount | 
        # | 128 b * numLogs | 8 bytes         | 8 bytes         | 8 bytes         | 
        # ------------------------------------------------------------------------- 
        # * HASH(PCertPub) and HASH(HCertPub) are the first 8 bytes of the SHA-1 hash of the 
        #   public key of PCert/HCert 

        # Step 10: Rebuild the exact byte sequence the HSM signed and hash it.
        # Concatenate all data for signature verification
        concatenated_data = binary_data + partition_pub_hash_prefix + hsm_pub_hash_prefix + drop_count_buffer
        actual_hash = hashlib.sha256(concatenated_data).digest()

        # Step 11: Compare our recomputed hash against the one recorded in the
        # .sign file. A mismatch here means the log data, the certificates, or
        # the drop count no longer match what the HSM signed. This check runs
        # first because it pinpoints *which* input changed, whereas a raw
        # signature failure only tells you that something did.
        # Verify SHA-256 hash of the concatenated data matches the hash included in the signature file
        if actual_hash == hash_buffer:
            logger.info(
                f"{GREEN}Success: Hash of the concatenated data matches the hash included in the signature file.{RESET}"
            )
        else:
            logger.error(
                f"{RED}Error: Hash of the concatenated data does not match the hash included in the signature file.{RESET}"
            )
            raise ValueError("Hash of the concatenated data does not match the hash included in the signature file")

        # Step 12: Verify the RSA-PKCS#1 v1.5 signature over the reconstructed
        # payload using the Partition certificate's public key. This is the
        # authoritative check: it proves the batch was produced by the HSM
        # holding the corresponding private key and has not been altered since.
        partition_public_key = partition_cert.public_key()
        if not isinstance(partition_public_key, rsa.RSAPublicKey):
            raise ValueError("Partition certificate public key is not RSA")      
        
        # Verify signature
        try:
            partition_public_key.verify(
                signature=signature_buffer,
                data=concatenated_data,
                padding=padding.PKCS1v15(), # CodeQL [SM04457] PKCS1v15 is used here because the signature was generated using RSASSA-PKCS1-v1_5 (RS256) as specified in the Azure Cloud HSM audit log signature scheme.
                algorithm=hashes.SHA256()
            )
            
            logger.info(f"{GREEN}Success: Signature verification succeeded. The audit logs are authentic and have not been tampered with.{RESET}")
        except InvalidSignature as exc:
            logger.error(f"{RED}Error: Signature verification failed.{RESET}")
            raise ValueError("Signature verification failed") from exc  

        logger.info(f"{GREEN}Audit logs signature verification completed.{RESET}")
    except Exception as error:
        # Any validation or verification failure lands here. The specific cause
        # is already logged above; this records the summary and flips the exit code.
        logger.error(f"{RED}Error verifying audit logs signature: {error}{RESET}")
        result_successful = False
    finally:
        # Always flush and close the log file, even on failure, so the customer
        # has a complete record of the verification attempt.
        logger.close()

    # Non-zero exit code lets shell scripts and CI pipelines detect failures.
    return 0 if result_successful else 1

# SIG # Begin Windows Authenticode signature block
# MIInUwYJKoZIhvcNAQcCoIInRDCCJ0ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBLtikbDAlQaGPg
# XWFLCdZzI5/Hip31x88C8aqkDPSykqCCDMkwggYEMIID7KADAgECAhMzAAACHPrN
# xZvoL37EAAAAAAIcMA0GCSqGSIb3DQEBCwUAMFcxCzAJBgNVBAYTAlVTMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBD
# b2RlIFNpZ25pbmcgUENBIDIwMjQwHhcNMjYwNDE2MTg1OTQxWhcNMjcwNDE1MTg1
# OTQxWjB0MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYD
# VQQDExVNaWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IB
# DwAwggEKAoIBAQDVsZfgOKmM31HPfoWOoNEiw0SlCiIxUMC0I9NMWbucKOw/e9lP
# oAoehQVu6SG65V4EPzrYsnBnFPNoi4/HoOdjhz1qkrEt4I6tEcxXU6oOeY9zGveC
# /3iBeuhLYxM3M/PkcUoebF+Nednm8OkdSPoDu8imViHPQq/8CQUu0WRR4rE+dMRf
# rpVqfmNi2qWCX94T4MsepijGVkwE//tJg0ryAiYdHT34LSnlG/RSBZmQRGWZ5g8j
# qnKjRParSqMft1gvjuUTVgtWNZfgcLFSK5Wa0myrq8OPcgTGGsRgun+tnSS+IxDT
# xVsAPH1OzvPjwomguByhUe/OcvUN0D5Wmp7xAgMBAAGjggGqMIIBpjAOBgNVHQ8B
# Af8EBAMCB4AwHwYDVR0lBBgwFgYKKwYBBAGCN0wIAQYIKwYBBQUHAwMwHQYDVR0O
# BBYEFNoH7a2YDjOSwpkp6DHcmUS7J+0yMFQGA1UdEQRNMEukSTBHMS0wKwYDVQQL
# EyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxFjAUBgNVBAUT
# DTIzMDAxMis1MDc1NjkwHwYDVR0jBBgwFoAUf1k/VCHarU/vBeXmo9ctBpQSCDEw
# YAYDVR0fBFkwVzBVoFOgUYZPaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9w
# cy9jcmwvTWljcm9zb2Z0JTIwQ29kZSUyMFNpZ25pbmclMjBQQ0ElMjAyMDI0LmNy
# bDBtBggrBgEFBQcBAQRhMF8wXQYIKwYBBQUHMAKGUWh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwQ29kZSUyMFNpZ25pbmcl
# MjBQQ0ElMjAyMDI0LmNydDAMBgNVHRMBAf8EAjAAMA0GCSqGSIb3DQEBCwUAA4IC
# AQAUnEqhaRXe0T3hIJjvdQErEkrA/7bByjn6t5IArODkkRjzkYwtKMc2yYj2quaN
# rLutWw2YZcngKPy1b71YyDJQTy4NDRwaSh9Tw5thrk3NmcPrAHia5vtcBJ1CgtKK
# 7mQbIcQ22d/N3813ayCDDFewu1+jsZmX+r/aTEqaOM4TVxVtRSkuCy8nAXKuChOK
# Li/zA4XuH8iEYqIsj2YoNaeSxVmeGiERXpKdo3dDmYi0kO5w2D8VS4c3+9h6gElY
# BaAAg/dYErBg27qT3vv0zRDJhJufvCNylA8S7/+8H5E/PV5cng6na9VV/w9OV3qu
# uND6zdGa2EX38Glp50F9AIQk3p2xXmcvorDeM4XJ7UlWYBi6g80J1SSOQnInCYFE
# msfUNn3+1AaTJKSJL83quKArTac2pKhu0Yzzzrzo6HrsRiQKzpnRBb1/dMa6P3hz
# 75XbMRBctNsFhZC07WCmjExdLg2eHW5uV0TY8D5+6wozJf7vF3+WHkYPO85Z+BC6
# U4FkNbYNycZ9cE4j1tXRdyDCfml6c0HWPHjNVDObrv9lKt3qUqFpX38VCqVCyNOO
# 1UcXfQiVjJw32U2WUKZjt/neJKHEBsm9kFsLuWzkQ53+qcaSaytmsCnk2gOglrlD
# 5d3kKyvvAw+rzm0lT8K38P6PLxfZQHhu4W8dV7Av8N2ZmDCCBr0wggSloAMCAQIC
# EzMAAAA5O7Y3Gb8GHWcAAAAAADkwDQYJKoZIhvcNAQEMBQAwgYgxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBS
# b290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDExMB4XDTI0MDgwODIwNTQxOFoX
# DTM2MDMyMjIyMTMwNFowVzELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EgMjAyNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANgBnB7jOMeq
# lRYHNa265v4IY9fH8TKhemHfPINe1gpLaV3dhg324WwH06LcHbpnsBukCDNitryo
# 0dtS/EW6I/yEL/bLSY8hKpbfQuWusBPr9qazYcDxCW/qnjb5JsI1s8bNOg3bVATv
# QVL4tcf03aTycsz8QeCdM0l/yHRObJ9QqazM1r6VPEOJ7LL+uEEb73w6QCuhs89a
# 1uv1zerOYMnsneRRwCbpyW11IcggU0cRKDDq1pjVJzIbIF6+oiXXbReOsgeI8zu1
# FyQfK0fVkaya8SmVHQ/tOf23mZ4W9k0Ri22QW9p3UgSC5OUDktKxxcCmGL6tXLfO
# GSWHIIV4YrTJTT6PNty5REojHJuZHArkF9VnHTERWoTjAzfI3kP+5b4alUdhgAZ7
# ttOu1bVnXfHaqPYl2rPs20ji03LOVWsh/radgE17es5hL+t6lV0eVHrVhsssROWJ
# uz2MXMCt7iw7lFPG9LXKGjsmonn2gotGdHIuEg5JnJMJVmixd5LRlkmgYRZKzhxS
# CwyoGIq0PhaA7Y+VPct5pCHkijcIIDm0nlkK+0KyepolcqGm0T/GYQRMhHJlGOOm
# VQop36wUVUYklUy++vDWeEgEo4s7hxN6mIbf2MSIQ/iIfMZgJxC69oukMUXCrOC3
# SkE/xIkgpfl22MM1itkZ35nNXkMolU1lAgMBAAGjggFOMIIBSjAOBgNVHQ8BAf8E
# BAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFH9ZP1Qh2q1P7wXl5qPX
# LQaUEggxMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAUci06AjGQQ7kUBU7h6qfHMdEjiTQwWgYDVR0fBFMwUTBP
# oE2gS4ZJaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljUm9vQ2VyQXV0MjAxMV8yMDExXzAzXzIyLmNybDBeBggrBgEFBQcBAQRSMFAw
# TgYIKwYBBQUHMAKGQmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMv
# TWljUm9vQ2VyQXV0MjAxMV8yMDExXzAzXzIyLmNydDANBgkqhkiG9w0BAQwFAAOC
# AgEAFJQfOChP7onn6fLIMKrSlN1WYKwDFgAddymOUO3FrM8d7B/W/iQ6DxXsDn7D
# 5W4wMwYeLystcEqfkjz4NURRgazyMu5yRzQh4LqjA4tStTcJh1opExo7nn5PuPBY
# nbu0+THSuVHTe0VTTPVhily/piFrDo3axQ9P4C+Ol5yet+2gTfekICS5xS+cYfSI
# vgn0JksVBVMYVI5QFu/qhnLhsEFEUzG8fvv0hjgkO+lkpV9ty6GkN4vdnd7ya6Q6
# aR9y34aiM1qmxaxBi6OUnyNl6fkuun/diTFnYDLTppOkr/mg5WSfCiDVMNCxtj4w
# PKC5OmHm1DQIt/MNokbbH3UGsFP1QbzsLocuSqLCvH09Io3fDPTmscR9Y75G4qX7
# RTX8AdBPo0I6OEojf39zuFZt0qOHm65YWQE69cZM2ueE1MB05dNNgHK9gTE7zKvK
# /fg8B2qjW88MT/WF5V5uvZGtqa9FSL2RazArA+rDPuf6JGYz4HpgMZHB4S6szWSK
# YBv0VisCzfxgeU+dquXW9bd0auYlOB58DPcOYKdc3Se94g+xL4pcEhbB54JOgAkw
# YTu/9dLeH2pDqeJZAABVDWRQCaXfO5LgyKwKCLYXpigrZYCjUSBcr+Ve8PFWMhVT
# Ql0v4q8J/AUmQN5W4n101cY2L4A7GTQG1h32HHAvfQESWP0xghngMIIZ3AIBATBu
# MFcxCzAJBgNVBAYTAlVTMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# KDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMjQCEzMAAAIc
# +s3Fm+gvfsQAAAAAAhwwDQYJYIZIAWUDBAIBBQCggZAwGQYJKoZIhvcNAQkDMQwG
# CisGAQQBgjcCAQQwLwYJKoZIhvcNAQkEMSIEIIMgdfPkpSyoNnTr1asCpm+RdOMq
# xTAHjK+sTmWRM1OoMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8AcwBv
# AGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAE
# ggEAR+D6NAAjyCgv7uaVtEtu+nTrZQigy83Rzav1PlLxSroxgr8E/vDKK3d21k77
# KQB9nqAiPHQ+vFT+0MPCM3N5cy2YX+uIFe3to0fXC8eylx4yXsrsZaePmQbkfQ13
# Ix3UPD0g9p0VaIHK/cnxdsSAn9abf0rYx+RsoX3JYe2xGi5Jw1hMRYCdxKzBwy93
# zExT8Zl52M0x7iI8YrSavazayqCd4fgveiSho1PSYS2xcmjkSgohDcA78+PQRQcg
# n2eRJqhAXKlDEexzNYPhgi8m7PvrQAAV7HhxUuN9zIDUhndNxLpSGco0/eM7RfM5
# kA04pIt8Wv5F2+/Pb2rTV1JEjKGCF7AwghesBgorBgEEAYI3AwMBMYIXnDCCF5gG
# CSqGSIb3DQEHAqCCF4kwgheFAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFaBgsqhkiG
# 9w0BCRABBKCCAUkEggFFMIIBQQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQC
# AQUABCAgeVvmK3FU0MlQ2P45BbCbhqy6L+IizPZYNGY+pbVe9wIGaq5iOeodGBMy
# MDI2MTAxMzAyNDMzNi4wMDVaMASAAgH0oIHZpIHWMIHTMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFu
# ZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjo0
# QzFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaCCEf4wggcoMIIFEKADAgECAhMzAAACGCXZkgXi5+XkAAEAAAIYMA0GCSqG
# SIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI1MDgx
# NDE4NDgyNVoXDTI2MTExMzE4NDgyNVowgdMxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjRDMUEtMDVF
# MC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIC
# IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAsdzo6uuQJqAfxLnvEBfIvj6k
# nK+p6bnMXEFZ/QjPOFywlcjDfzI8Dg1nzDlxm7/pqbvjWhyvazKmFyO6qbPwClfR
# nI57h5OCixgpOOCGJJQIZSTiMgui3B8DPiFtJPcfzRt3FsnxjLXwBIjGgnjGfmQl
# 7zejA1WoYL/qBmQhw/FDFTWebxfo4m0RCCOxf2qwj31aOjc2aYUePtLMXHsXKPFH
# 0tp5SKIF/9tJxRSg0NYEvQqVilje8aQkPd3qzAux2Mc5HMSK4NMTtVVCYAWDUZ4p
# +6iDI9t5BNCBIsf5ooFNUWtxCqnpFYiLYkHfFfxhVUBZ8LGGxYsA36snD65s2Hf4
# t86k0e8WelH/usfhYqOM3z2yaI8rg08631IkwqUzyQoEPqMsHgBem1xpmOGSIUnV
# vTsAv+lmECL2RqrcOZlZax8K0aiij8h6UkWBN2IA/ikackTSGVRBQmWWZuLFWV/T
# 4xuNzscC0X7xo4fetgpsqaEA0jY/QevkTvLv4OlNN9eOL8LNh7Vm0R65P7oabOQD
# qtUFAwCgjgPJ0iV/jQCaMAcO3SYpG5wSAYiJkk4XLjNSlNxU2Idjs1sORhl7s7LC
# 6hOb7bVAHVwON74GxfFNiEIA6BfudANjpQJ0nUc/ppEXpT4pgDBHsYtV8OyKSjKs
# IxOdFR7fIJIjDc8DvUkCAwEAAaOCAUkwggFFMB0GA1UdDgQWBBQkLqHEXDobY7dH
# uoQCBa4sX7aL0TAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNV
# HR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2Ny
# bC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYI
# KwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAy
# MDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMI
# MA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAnkjRhjwPgdoIpvt4
# YioT/j0LWuBxF3ARBKXDENggraKvC0oRPwbjAmsXnPEmtuo5MD8uJ9Xw9eYrxqqk
# K4DF9snZMrHMfooxCa++1irLz8YoozC4tci+a4N37Sbke1pt1xs9qZtvkPgZGWn5
# BcwVfmAwSZLHi2CuZ06Y0/X+t6fNBnrbMVovNaDX4WPdyI9GEzxfIggDsck2Ipo4
# VXL/Arcz7p2F7bEZGRuyxjgMC+woCkDJaH/yk/wcZpAsixe4POdN0DW6Zb35O3Dg
# 3+a6prANMc3WIdvfKDl75P0aqcQbQAR7b0f4gH4NMkUct0Wm4GN5KhsE1YK7V/wA
# qDKmK4jx3zLz3a8Hsxa9HB3GyitlmC5sDhOl4QTGN5kRi6oCoV4hK+kIFgnkWjHh
# SRNomz36QnbCSG/BHLEm2GRU9u3/I4zUd9E1AC97IJEGfwb+0NWb3QEcrkypdGdW
# wl0LEObhrQR9B1V7+edcyNmsX0p2BX0rFpd1PkXJSbxf8IcEiw/bkNgagZE+VlDt
# xXeruLdo5k3lGOv7rPYuOEaoZYxDvZtpHP9P36wmW4INjR6NInn2UM+krP/xeLnR
# bDBkm9RslnoDhVraliKDH62BxhcgL9tiRgOHlcI0wqvVWLdv8yW8rxkawOlhCRqT
# 3EKECW8ktUAPwNbBULkT+oWcvBcwggdxMIIFWaADAgECAhMzAAAAFcXna54Cm0mZ
# AAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMyMjVa
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0BAQEF
# AAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51yMo1
# V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY6GB9
# alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9cmmv
# Haus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN7928
# jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDuaRr3t
# pK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74kpEe
# HT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2K26o
# ElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5TI4C
# vEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZki1ug
# poMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9QBXps
# xREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3PmriLq0C
# AwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUCBBYE
# FCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJlpxtT
# NRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIBFjNo
# dHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9yeS5o
# dG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBD
# AEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZW
# y4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAt
# MDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0y
# My5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/ypb+pc
# FLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulmZzpT
# Td2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM9W0j
# VOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECWOKz3
# +SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4FOmR
# sqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3UwxTSw
# ethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPXfx5b
# RAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVXVAmx
# aQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGConsX
# HRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU5nR0
# W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEGahC0
# HVUzWLOhcGbyoYIDWTCCAkECAQEwggEBoYHZpIHWMIHTMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFu
# ZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjo0
# QzFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAnWtGrXWiuNE8QrKfm4CtGr57z+mggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsFAAIF
# AO532XkwIhgPMjAyNjEwMTIyMjExMDVaGA8yMDI2MTAxMzIyMTEwNVowdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA7nfZeQIBADAKAgEAAgIK0QIB/zAHAgEAAgISezAK
# AgUA7nkq+QIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBCwUAA4IBAQC74ZvxtVbtc1JS
# knn0jn4itk9YBfS2xagTeNFN0F4gZkA0pqeSMMnVvMEiQMNXjNQ0C9Cc6LnOAtZ+
# +VoRSv1Idy3UktV0RCpgMr5lhC/DFps8PsGHyq7FahgzSbD/ASQO+pRe78s7Y5+6
# KGwpGQlzNcPsa1owST4IBCTf+kZL3/+Ri7sDxOGODrsdsZ1SAayGlNnJMAai0tMi
# BKnyWhaTrmkAsnvI7WmSA/FhBbZWKzFcNtEb1F5nxjbKBwfunWpucqZc1RLpjsAs
# FcFhOJqYtCMenCR7Dsjw0zwpkxk8WlT73VfXYlwfGhhoeyvJH+/A6/2018YVaaxC
# /fiuWVX8MYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTACEzMAAAIYJdmSBeLn5eQAAQAAAhgwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqG
# SIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQge494MxMn4nel
# rVMbt/CQYIRpKhuZu8kN1GQ5LMQGnPYwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHk
# MIG9BCCZE9yJuOTItIwWaES6lzGKK1XcSoz1ynRzaOVzx9eFajCBmDCBgKR+MHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAACGCXZkgXi5+XkAAEAAAIY
# MCIEICTB/CoVyKhIB6k0zSPXivltSYPHa8OQ6XB039zN+MWpMA0GCSqGSIb3DQEB
# CwUABIICAB/M0ISxcnl9SGmF+WZd6BMpRO55ifgwDNvzKhzlmN/E4cAPgjEK7yR9
# DhutSfWJMRx9CfNNKFn7G7AK3KMANOERWapWSi/QLfvng4asz+g2J2LUEia35swP
# bcw9721TBNhkoi8rFcOEODn33q4a94FL5JmjX6ejiz2CWsaBKx9mrm1yJjjXvZEl
# Bcm9BjxLHgm9tFvWKNg5AdpXY/X5SpJq06rcgceA8uBOWI3eWb6kg3EpTazSSw0Q
# BwzQyr9WRTI5DWYcWtXdu0cOOnMQOXzn4J+srcQPF+zdTPa2MZ0AfFrZdgd7MIhm
# cgbAzhpt6VtQ2i+d+asGqcA+D8u5syAyB4XFR+dZ88Q0Bx82ya6FqgQWjXSmyYYC
# 0QQZXsX5b23Sx4MLYiWnk6rNiYSVOcc04pn9WXSz/0ub5mSgOwJrql0kKo00WeJP
# ZwFqxEkFEvuXt17JNxQ9f2XNtlMLtS+8wWNZLCJtapDCgJaScoFypem4CBUt8fBT
# saUY0GYLrDARwllPzL1AqeFg+gzqZoJ8YkJ6GLSUaWaBiiv3S4/dxiMGdaS/G17u
# 8MyiRL4HTWnX44yWFEUvrsnU4Tg1WDdgP3yrDTqo6ebC/eyy946mVJWA0Y4lXYjL
# la4P4A0qizi76zrc7JeoTLPf6TkSPzOk3alVU9yHY6lZ9IE21y4c
# SIG # End Windows Authenticode signature block