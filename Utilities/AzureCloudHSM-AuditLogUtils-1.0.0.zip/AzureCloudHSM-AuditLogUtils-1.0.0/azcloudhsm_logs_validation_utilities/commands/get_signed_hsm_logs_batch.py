# Copyright (C) Microsoft. All rights reserved.

from __future__ import annotations

import argparse
import base64
from __init__ import __version__
import json
import re
from pathlib import Path
from typing import Dict, Generator, List, Optional

from constants import (
    AUDIT_LOG_RECORD_SIZE,
    SHA256_HASH_LENGTH,
    SIGNATURE_RECORD_DATA_LENGTH,
)
from tracer import GREEN, RED, RESET, Logger

CORRELATION_ID_REGEX = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

def _create_correlation_id_bucket() -> Dict[str, object]:
    """Create an empty aggregation bucket for one correlation id."""
    # A "bucket" accumulates every piece of a single signed batch as the audit
    # log export is read. The records for one batch are spread across many rows
    # in the export, so they are collected here and validated as a set once the
    # whole file has been scanned.
    return {
        # Decoded 128-byte audit records, in the order encountered (sorted later).
        "auditLogs": [],
        # RSA signature the HSM produced over this batch.
        "signature": None,
        # SHA-256 hash the HSM computed over the signed payload.
        "hash": None,
        # Partition (signing) certificate, base64-encoded DER plus its format tag.
        "partition_cert_base64": None,
        "partition_cert_format": None,
        # HSM Owner Auth certificate, base64-encoded DER plus its format tag.
        "hsm_owner_auth_cert_base64": None,
        "hsm_owner_auth_cert_format": None,
    }


def _process_audit_record_for_correlation_id(logger: Logger, correlation_id: str, audit_record: Dict[str, object], bucket: Dict[str, object]) -> None:
    """Parse and validate one audit record, then merge it into the correlation id bucket."""
    # Step 1: Determine what kind of record this is. A batch in the export is a
    # mix of ordinary audit entries plus a handful of special marker records
    # (signature, certificates) identified by their OperationName. AdditionalInfo
    # carries per-record metadata such as the hash or the certificate size.
    operation_name : str = str(audit_record.get("OperationName", "")).upper()
    additional_info = json.loads(str(audit_record.get("AdditionalInfo", "{}")))    

    # Step 2: The signature record carries the HSM's RSA signature over the batch
    # and the SHA-256 hash it signed. Exactly one of these exists per batch.
    if operation_name == "BATCH_BINARY_SIGNATURE":
        logger.info(f"Found signature record for correlation id {correlation_id}")
        signature_buffer = base64.b64decode(audit_record.get("BinarySignature", "").strip(), validate=True)
        logger.info(f"Decoded signature buffer length: {len(signature_buffer)} bytes for correlation id {correlation_id}")
        hash_buffer = base64.b64decode(additional_info.get("hash", "").strip(), validate=True)
        logger.info(f"Decoded hash buffer length: {len(hash_buffer)} bytes for correlation id {correlation_id}")

        # Both fields are fixed width. A wrong length means the export was
        # truncated or altered, so fail loudly rather than emit a bad .sign file.
        if len(signature_buffer) != SIGNATURE_RECORD_DATA_LENGTH:
            logger.error(
                f"{RED}Error: Signature record data length is not {SIGNATURE_RECORD_DATA_LENGTH} bytes "
                f"for correlation id {correlation_id}.{RESET}"
            )
            raise ValueError(f"Invalid signature record data length: {len(signature_buffer)} bytes for correlation id {correlation_id}")

        if len(hash_buffer) != SHA256_HASH_LENGTH:
            logger.error(
                f"{RED}Error: Signature record hash length is not {SHA256_HASH_LENGTH} bytes for correlation id {correlation_id}.{RESET}"
            )
            raise ValueError(f"Invalid signature record hash length: {len(hash_buffer)} bytes for correlation id {correlation_id}")

        bucket["signature"] = signature_buffer
        bucket["hash"] = hash_buffer
    # Step 3: The partition certificate record holds the signing certificate.
    # Its public key is what `verify-audit-logs-signature` uses to check the
    # signature, so it is carried through to the _certs.json output verbatim.
    elif operation_name == "BATCH_PARTITION_IDENTITY_CERT":
        logger.info(f"Found partition certificate record for correlation id {correlation_id}")
        bucket["partition_cert_base64"] = audit_record.get("BinaryLogData", "").strip()
        bucket["partition_cert_format"] = str(additional_info.get("format", "")).lower()
        if bucket["partition_cert_format"] == "der":
            _validate_cert_record_size(
                logger,
                correlation_id,
                int(additional_info.get("cert_size", -1)),
                str(bucket["partition_cert_base64"]),
                "Partition",
            )
        else:
            logger.error(
                f"{RED}Error: Invalid partition certificate format for correlation id {correlation_id}. Expected 'der'.{RESET}"
            )
            raise ValueError(f"Invalid partition certificate format for correlation id {correlation_id}")
    # Step 4: The HSM Owner Auth certificate record. Its public key hash is also
    # folded into the signed payload, so it must be captured for verification.
    elif operation_name == "BATCH_HSM_OWNER_AUTH_CERT":
        logger.info(f"Found HSM certificate record for correlation id {correlation_id}")
        bucket["hsm_owner_auth_cert_base64"] = audit_record.get("BinaryLogData", "").strip()
        bucket["hsm_owner_auth_cert_format"] = str(additional_info.get("format", "")).lower()
        if bucket["hsm_owner_auth_cert_format"] == "der":
            _validate_cert_record_size(
                logger,
                correlation_id,
                int(additional_info.get("cert_size", -1)),
                str(bucket["hsm_owner_auth_cert_base64"]),
                "HSM",
            )
        else:
            logger.error(
                f"{RED}Error: Invalid HSM certificate format for correlation id {correlation_id}. Expected 'der'.{RESET}"
            )
            raise ValueError(f"Invalid HSM certificate format for correlation id {correlation_id}")
    # Step 5: Anything else is an ordinary audit entry and forms part of the
    # signed payload. The device and manufacturer root certificate records are
    # deliberately skipped: they are informational and are NOT covered by the
    # signature, so including them would corrupt the reconstructed batch.
    elif operation_name != "BATCH_HSM_DEVICE_CERT" and operation_name != "BATCH_HSM_MANUFACTURER_ROOT_CERT":
        audit_data = base64.b64decode(audit_record.get("BinaryLogData", "").strip(), validate=True)
        # Every audit entry is exactly 128 bytes. Any other size means the record
        # was corrupted in transit, which would silently break verification later.
        if len(audit_data) != AUDIT_LOG_RECORD_SIZE:
            sequence_no = audit_record.get("SequenceNumber")
            logger.error(
                f"{RED}Error: Audit log entry with sequenceNo. {sequence_no} has data length that is not "
                f"{AUDIT_LOG_RECORD_SIZE} bytes for correlation id {correlation_id}.{RESET}"
            )
            raise ValueError(
                f"Invalid audit log entry with sequenceNo. {sequence_no} has data length: {len(audit_data)} bytes for correlation id {correlation_id}"
            )
        # Keep the sequence number alongside the data; the records are ordered by
        # it later, since the export does not guarantee any particular row order.
        bucket["auditLogs"].append({"sequenceNo": audit_record.get("SequenceNumber"), "audit_data": audit_data})

def _load_audit_records(file_path: Path) -> Generator[Dict[str, object], None, None]:
    """Yield non-empty JSON objects from a Log Analytics export."""
    with file_path.open("r", encoding="utf-8-sig") as handle:
        # Step 1: Parse the Log Analytics export. Two shapes are accepted:
        # a JSON object whose "Results" array holds one entry per exported audit
        # row, as produced by Azure PowerShell using
        # `Invoke-AzOperationalInsightsQuery`, and a top-level array of records,
        # as produced by the Azure CLI by running `az monitor log-analytics query`.
        document = json.load(handle)

        # Step 2: Reject anything that is not a recognizable export, so the user
        # gets a clear message instead of a downstream attribute error.
        if isinstance(document, list):
            results = document
        elif isinstance(document, dict):
            results = document.get("Results")
        else:
            results = None

        if results is None or not isinstance(results, list):
            raise ValueError(
                f"Invalid JSON structure: expected either a top-level 'Results' array or a "
                f"top-level array of audit records in file {file_path}"
            )
        
        # Step 3: Hand back one record at a time. Yielding keeps only a single
        # record in play per iteration, which matters for large exports.
        for audit_record in results:
            if isinstance(audit_record, dict) and audit_record:
                yield audit_record
            else:
                raise ValueError(f"Invalid audit record: {audit_record} in file {file_path}")


def _validate_cert_record_size(logger: Logger, correlation_id: str, cert_size: int, cert_base64: str, cert_name: str) -> None:
    """Validate the decoded certificate size against the size recorded in command info."""
    # The HSM records the certificate's byte length in AdditionalInfo. Comparing
    # it against the actual decoded length is a cheap integrity check that
    # catches a certificate truncated or padded during export.
    actual_size = len(base64.b64decode(cert_base64, validate=True))
    
    if cert_size != actual_size:
        logger.error(
            f"{RED}Error: {cert_name} certificate record size mismatch for correlation id {correlation_id}. "
            f"Expected size {cert_size}, actual size {actual_size}.{RESET}"
        )
        raise ValueError(
            f"{cert_name} certificate record size mismatch for correlation id {correlation_id}. "
            f"Expected size {cert_size}, actual size {actual_size}"
        )


def _validate_and_finalize_parse_result(
    logger: Logger,
    correlation_id: str,
    binary_audit_logs: List[Dict[str, object]],
    binary_signature: Optional[bytes],
    binary_hash: Optional[bytes],
    partition_cert_base64: Optional[str],
    partition_cert_format: Optional[str],
    hsm_owner_auth_cert_base64: Optional[str],
    hsm_owner_auth_cert_format: Optional[str],
) -> Dict[str, object]:
    """Validate required artifacts for one correlation id and return normalized parse output."""
    # Step 1: A batch is only usable if every piece was found in the export. Each
    # check below reports a distinct missing component so the user knows exactly
    # which records the export was missing (commonly caused by too narrow a Log
    # Analytics time range or filter).
    if len(binary_audit_logs) == 0:
        logger.error(
            f"{RED}Error: No audit log entries found for correlation id {correlation_id}.{RESET}"
        )
        raise ValueError(f"No audit log entries found for correlation id {correlation_id}")

    if not binary_signature:
        logger.error(
            f"{RED}Error: No signature record found for correlation id {correlation_id}.{RESET}"
        )
        raise ValueError(f"No signature record found for correlation id {correlation_id}")

    if not binary_hash:
        logger.error(
            f"{RED}Error: No hash found in signature record for correlation id {correlation_id}.{RESET}"
        )
        raise ValueError(f"No hash found in signature record for correlation id {correlation_id}")

    if not partition_cert_base64:
        logger.error(
            f"{RED}Error: No partition certificate record found for correlation id {correlation_id}.{RESET}"
        )
        raise ValueError(f"No partition certificate record found for correlation id {correlation_id}")

    if not partition_cert_format:
        logger.error(
            f"{RED}Error: No partition certificate format found for correlation id {correlation_id}.{RESET}"
        )
        raise ValueError(f"No partition certificate format found for correlation id {correlation_id}")

    if not hsm_owner_auth_cert_base64:
        logger.error(
            f"{RED}Error: No HSM certificate record found for correlation id {correlation_id}.{RESET}"
        )
        raise ValueError(f"No HSM certificate record found for correlation id {correlation_id}")

    if not hsm_owner_auth_cert_format:
        logger.error(
            f"{RED}Error: No HSM certificate format found for correlation id {correlation_id}.{RESET}"
        )
        raise ValueError(f"No HSM certificate format found for correlation id {correlation_id}")


    # Step 2: Order the audit records by sequence number. The HSM signed the
    # records in this exact order, so the concatenated .bin file will only hash
    # correctly if it is reassembled the same way. Sequence numbers are
    # hexadecimal strings, hence the base-16 conversion.
    binary_audit_logs = sorted(binary_audit_logs, key=lambda e: int(str(e["sequenceNo"]), 16))

    # Step 3: Return a normalized result with the sequence numbers dropped, ready
    # to be written out as the .bin, .sign, and _certs.json artifacts.
    return {
        "binary_audit_logs": [e["audit_data"] for e in binary_audit_logs],
        "binary_signature": binary_signature,
        "binary_hash": binary_hash,
        "partition_cert_base64": partition_cert_base64,
        "partition_cert_format": partition_cert_format,
        "hsm_owner_auth_cert_base64": hsm_owner_auth_cert_base64,
        "hsm_owner_auth_cert_format": hsm_owner_auth_cert_format,
    }


def _save_binary_data_to_file(logger: Logger, binary_data: bytes, output_file_path: Path) -> None:
    """Write binary data to disk, creating parent directory and overwriting existing files."""
    # Create output directory if not exists
    output_file_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Remove file if it exists
    if output_file_path.exists():
        output_file_path.unlink()
        
    output_file_path.write_bytes(binary_data)
    logger.info(f"Saved binary data to file at path: {output_file_path}")


def _save_correlation_id_files(logger: Logger, correlation_id: str, result: Dict[str, object]) -> None:
    """Persist .bin, .sign, and cert JSON artifacts for a correlation id."""
    # Step 1: All artifacts land in a binary_audit_files/ folder under the current
    # working directory, named after the correlation id so batches never collide.
    output_dir = Path.cwd() / "binary_audit_files"

    output_bin_file = f"audit_logs_{correlation_id}.bin"
    output_sign_file = f"audit_logs_{correlation_id}.sign"

    # Step 2: Write the .bin file. This is the signed batch itself: every 128-byte
    # audit record concatenated in sequence-number order, with no delimiters.
    _save_binary_data_to_file(logger, b"".join(result["binary_audit_logs"]), output_dir / output_bin_file)
    logger.info(f"{GREEN}Successfully saved binary audit logs to file: {output_bin_file}{RESET}")

    # Step 3: Write the .sign file as signature followed by hash. The signature
    # blob already contains the dropped-log count, giving the 296-byte layout
    # (256 signature + 8 drop count + 32 hash) that the verify command expects.
    _save_binary_data_to_file(logger, result["binary_signature"] + result["binary_hash"], output_dir / output_sign_file)
    logger.info(f"{GREEN}Successfully saved binary signature to file: {output_sign_file}{RESET}")

    # Step 4: Write the certificates extracted from the audit log itself. Bundling
    # them here means the customer needs no separate certificate download to
    # verify the batch offline.
    # Save certificates to a JSON file
    output_cert_file = f"audit_logs_{correlation_id}_certs.json"
    cert_json = {
        "partition_cert_base64": result["partition_cert_base64"],
        "partition_cert_format": result["partition_cert_format"],
        "hsm_owner_auth_cert_base64": result["hsm_owner_auth_cert_base64"],
        "hsm_owner_auth_cert_format": result["hsm_owner_auth_cert_format"],
    }

    output_cert_file = output_dir / output_cert_file
    output_cert_file.write_text(json.dumps(cert_json, indent=1), encoding="utf-8")
    logger.info(f"{GREEN}Successfully saved certificates to file: {output_cert_file}{RESET}")


def _parse_hsm_operation_records(logger: Logger, file_path: Path, correlation_id: str) -> Dict[str, object]:
    """Process a JSONL audit file for a single correlation id."""
    logger.info(f"Parsing audit logs for correlation id: {correlation_id}")

    # Step 1: Start with an empty bucket for the one batch we care about.
    bucket = _create_correlation_id_bucket()
    line_count = 0

    # Step 2: Walk every record in the export, ignoring anything that belongs to
    # a different batch, and merge the matching records into the bucket.
    for audit_record in _load_audit_records(file_path):
        line_count += 1
        if audit_record.get("CorrelationId") != correlation_id:
            continue

        _process_audit_record_for_correlation_id(logger, correlation_id, audit_record, bucket)                

    logger.info(f"Total lines read from audit log file: {line_count}")

    # Step 3: Confirm the batch is complete and return it in sorted, normalized
    # form. Raises if any required record was absent from the export.
    return _validate_and_finalize_parse_result(
        logger,
        correlation_id,
        bucket["auditLogs"],
        bucket["signature"],
        bucket["hash"],
        bucket["partition_cert_base64"],
        bucket["partition_cert_format"],
        bucket["hsm_owner_auth_cert_base64"],
        bucket["hsm_owner_auth_cert_format"],
    )


def _stream_and_process_all_correlation_ids(logger: Logger, file_path: Path) -> None:
    """Process a JSONL audit file once and generate artifacts for every discovered correlation id."""
    logger.info(f"Streaming audit log file to process all correlation ids: {file_path}")

    # Step 1: Maintain one bucket per correlation id so an export containing many
    # batches can be split apart in a single pass over the file.
    correlation_id_map: Dict[str, Dict[str, object]] = {}
    line_count = 0

    # Step 2: Read every record once, routing each into the bucket for its batch.
    for audit_record in _load_audit_records(file_path):
        line_count += 1
        correlation_id = str(audit_record.get("CorrelationId", "")).strip()
        if not correlation_id:
            continue
        
        # Skip rows whose correlation id is malformed rather than aborting: one
        # bad row should not prevent the remaining batches from being built.
        # Check correlation id matches expected format
        if CORRELATION_ID_REGEX.match(correlation_id) is None:
            logger.error(f"{RED}Error: Invalid correlation id format: {correlation_id}{RESET}")
            continue

        if correlation_id not in correlation_id_map:
            correlation_id_map[correlation_id] = _create_correlation_id_bucket()

        bucket = correlation_id_map[correlation_id]
        _process_audit_record_for_correlation_id(logger, correlation_id, audit_record, bucket)

    logger.info(f"Total lines read from audit log file: {line_count}")

    # Step 3: An export with no usable correlation ids means the query returned
    # nothing relevant, so there is nothing to build.
    if len(correlation_id_map) == 0:
        logger.error(f"{RED}Error: No correlation ids found in audit log file.{RESET}")
        raise ValueError("No correlation ids found in audit log file")

    logger.info(f"Found {len(correlation_id_map)} unique correlation id(s) in audit log file.")
    failed_correlation_ids: List[str] = []

    # Step 4: Finalize and write out each batch independently. Failures are
    # collected rather than raised immediately so that one incomplete batch does
    # not prevent the other valid batches in the export from being produced.
    for correlation_id, bucket in correlation_id_map.items():
        try:
            result = _validate_and_finalize_parse_result(
                logger,
                correlation_id,
                bucket["auditLogs"],
                bucket["signature"],
                bucket["hash"],
                bucket["partition_cert_base64"],
                bucket["partition_cert_format"],
                bucket["hsm_owner_auth_cert_base64"],
                bucket["hsm_owner_auth_cert_format"],
            )
            _save_correlation_id_files(logger, correlation_id, result)
        except Exception as error:
            logger.error(f"{RED}Error processing correlation id {correlation_id}: {error}{RESET}")
            failed_correlation_ids.append(correlation_id)

    # Step 5: Surface a non-zero result if any batch failed, naming the offenders
    # so the customer can re-export just those correlation ids.
    if len(failed_correlation_ids) > 0:
        logger.error(f"{RED}Failed to process {len(failed_correlation_ids)} correlation id(s): {','.join(failed_correlation_ids)}{RESET}")
        raise ValueError(f"Failed to process {len(failed_correlation_ids)} correlation id(s)")

    logger.info(f"{GREEN}Successfully processed all {len(correlation_id_map)} correlation id(s).{RESET}")


def run_get_signed_hsm_logs_batch(args : argparse.Namespace) -> int:
    """CLI entrypoint that gets the signed binary batch by combining the individual audit log binary records."""
    logger = Logger("get-signed-audit-log-batch")
    
    # Log CLI version
    logger.info(f"get-signed-audit-log-batch version: {__version__}")
    
    result_successful = True
    try:
        # Step 1: Echo the resolved arguments into the log file. The log is the
        # artifact customers attach to support cases, so it must record exactly
        # which input file and correlation id this run was asked to process.
        options = {
            "auditLogFile": args.audit_log_file,
            "correlationId": args.correlation_id,
        }
        logger.info(f"Parsed arguments: {json.dumps(options, indent=1)}")

        # Step 2: Validate the audit log file argument. argparse already enforces
        # that -f is present, so this guards against an explicitly empty value.
        if not args.audit_log_file:
            logger.error(f"{RED}Error: -f or --audit-log-file argument is required.{RESET}")
            raise ValueError("Audit log file path is required")

        # Step 3: Validate the optional correlation id. Rejecting a malformed id
        # up front produces a clear error instead of the confusing "no audit log
        # entries found" failure that a typo would otherwise cause later on.
        if args.correlation_id is not None:
            if args.correlation_id.strip() == "":
                logger.error(f"{RED}Error: Correlation id cannot be empty.{RESET}")
                raise ValueError("Correlation id cannot be empty")

            # Correlation id should match format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
            if not CORRELATION_ID_REGEX.match(args.correlation_id.strip()):
                logger.error(
                    f"{RED}Error: Correlation id format is invalid. Expected format: "
                    f"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx{RESET}"
                )
                raise ValueError("Correlation id format is invalid")

        # Step 4: Confirm the audit log export actually exists and has content.
        # An empty file usually means the Log Analytics export returned no rows.
        file_path = Path(args.audit_log_file)
        if not file_path.exists():
            logger.error(f"{RED}Error: File not found at path '{args.audit_log_file}'.{RESET}")
            raise ValueError(f"File not found at path '{args.audit_log_file}'")

        if file_path.stat().st_size == 0:
            logger.error(f"{RED}Error: Audit log file is empty at path '{args.audit_log_file}'.{RESET}")
            raise ValueError(f"Audit log file is empty at path '{args.audit_log_file}'")

        # Step 5: Assemble the signed batch(es). Each batch is assembled by decoding
        # the base64 `BinaryLogData` of every audit record for a correlation id,
        # ordering the records by sequence number, and concatenating them into a
        # single .bin blob. The matching .sign (signature + hash) and _certs.json
        # (Partition and HSM Owner Auth certificates) files are emitted alongside
        # it so `verify-audit-logs-signature` has everything it needs.
        if args.correlation_id:
            correlation_id = args.correlation_id.strip()
            # Single correlation id mode: read the file once, keeping only the
            # records that belong to the requested batch.
            result = _parse_hsm_operation_records(logger, file_path, correlation_id)
            _save_correlation_id_files(logger, correlation_id, result)
        else:
            # All correlation ids mode: read the file once and fan the records
            # out into one bucket per correlation id, so an export containing
            # many batches is processed in a single pass.
            _stream_and_process_all_correlation_ids(logger, file_path)
    except Exception as error:
        # Any validation or parsing failure lands here. The message is already
        # logged in detail above; this records the summary and flips the exit code.
        logger.error(f"{RED}Error getting signed audit log batch: {error}{RESET}")
        result_successful = False
    finally:
        # Always flush and close the log file, even on failure, so the customer
        # has a complete record of the run to share when troubleshooting.
        logger.info("Closing logger")
        logger.close()

    # Non-zero exit code indicates failure.
    return 0 if result_successful else 1

# SIG # Begin Windows Authenticode signature block
# MIInTwYJKoZIhvcNAQcCoIInQDCCJzwCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA+GgOGrfyVgsQE
# G4rb0ZoBpcpNZu875rkkT6H2A9SPF6CCDMkwggYEMIID7KADAgECAhMzAAACHPrN
# xZvoL37EAAAAAAIcMA0GCSqGSIb3DQEBCwUAMFcxCzAJBgNVBAYTAlVTMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBD
# b2RlIFNpZ25pbmcgUENBIDIwMjQwHhcNMjYwNDE2MTg1OTQxWhcNMjcwNDE1MTg1
# OTQxWjB0MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYD
# VQQDExVNaWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IB
# DwAwggEKAoIBAQDVsZfgOKmM31HPfoWOoNEiw0SlCiIxUMC0I9NMWbucKOw/e9lP
# oAoehQVu6SG65V4EPzrYsnBnFPNoi4/HoOdjhz1qkrEt4I6tEcxXU6oOeY9zGveC
# /3iBeuhLYxM3M/PkcUoebF+Nednm8OkdSPoDu8imViHPQq/8CQUu0WRR4rE+dMRf
# rpVqfmNi2qWCX94T4MsepijGVkwE//tJg0ryAiYdHT34LSnlG/RSBZmQRGWZ5g8j
# qnKjRParSqMft1gvjuUTVgtWNZfgcLFSK5Wa0myrq8OPcgTGGsRgun+tnSS+IxDT
# xVsAPH1OzvPjwomguByhUe/OcvUN0D5Wmp7xAgMBAAGjggGqMIIBpjAOBgNVHQ8B
# Af8EBAMCB4AwHwYDVR0lBBgwFgYKKwYBBAGCN0wIAQYIKwYBBQUHAwMwHQYDVR0O
# BBYEFNoH7a2YDjOSwpkp6DHcmUS7J+0yMFQGA1UdEQRNMEukSTBHMS0wKwYDVQQL
# EyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxFjAUBgNVBAUT
# DTIzMDAxMis1MDc1NjkwHwYDVR0jBBgwFoAUf1k/VCHarU/vBeXmo9ctBpQSCDEw
# YAYDVR0fBFkwVzBVoFOgUYZPaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9w
# cy9jcmwvTWljcm9zb2Z0JTIwQ29kZSUyMFNpZ25pbmclMjBQQ0ElMjAyMDI0LmNy
# bDBtBggrBgEFBQcBAQRhMF8wXQYIKwYBBQUHMAKGUWh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwQ29kZSUyMFNpZ25pbmcl
# MjBQQ0ElMjAyMDI0LmNydDAMBgNVHRMBAf8EAjAAMA0GCSqGSIb3DQEBCwUAA4IC
# AQAUnEqhaRXe0T3hIJjvdQErEkrA/7bByjn6t5IArODkkRjzkYwtKMc2yYj2quaN
# rLutWw2YZcngKPy1b71YyDJQTy4NDRwaSh9Tw5thrk3NmcPrAHia5vtcBJ1CgtKK
# 7mQbIcQ22d/N3813ayCDDFewu1+jsZmX+r/aTEqaOM4TVxVtRSkuCy8nAXKuChOK
# Li/zA4XuH8iEYqIsj2YoNaeSxVmeGiERXpKdo3dDmYi0kO5w2D8VS4c3+9h6gElY
# BaAAg/dYErBg27qT3vv0zRDJhJufvCNylA8S7/+8H5E/PV5cng6na9VV/w9OV3qu
# uND6zdGa2EX38Glp50F9AIQk3p2xXmcvorDeM4XJ7UlWYBi6g80J1SSOQnInCYFE
# msfUNn3+1AaTJKSJL83quKArTac2pKhu0Yzzzrzo6HrsRiQKzpnRBb1/dMa6P3hz
# 75XbMRBctNsFhZC07WCmjExdLg2eHW5uV0TY8D5+6wozJf7vF3+WHkYPO85Z+BC6
# U4FkNbYNycZ9cE4j1tXRdyDCfml6c0HWPHjNVDObrv9lKt3qUqFpX38VCqVCyNOO
# 1UcXfQiVjJw32U2WUKZjt/neJKHEBsm9kFsLuWzkQ53+qcaSaytmsCnk2gOglrlD
# 5d3kKyvvAw+rzm0lT8K38P6PLxfZQHhu4W8dV7Av8N2ZmDCCBr0wggSloAMCAQIC
# EzMAAAA5O7Y3Gb8GHWcAAAAAADkwDQYJKoZIhvcNAQEMBQAwgYgxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBS
# b290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDExMB4XDTI0MDgwODIwNTQxOFoX
# DTM2MDMyMjIyMTMwNFowVzELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EgMjAyNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANgBnB7jOMeq
# lRYHNa265v4IY9fH8TKhemHfPINe1gpLaV3dhg324WwH06LcHbpnsBukCDNitryo
# 0dtS/EW6I/yEL/bLSY8hKpbfQuWusBPr9qazYcDxCW/qnjb5JsI1s8bNOg3bVATv
# QVL4tcf03aTycsz8QeCdM0l/yHRObJ9QqazM1r6VPEOJ7LL+uEEb73w6QCuhs89a
# 1uv1zerOYMnsneRRwCbpyW11IcggU0cRKDDq1pjVJzIbIF6+oiXXbReOsgeI8zu1
# FyQfK0fVkaya8SmVHQ/tOf23mZ4W9k0Ri22QW9p3UgSC5OUDktKxxcCmGL6tXLfO
# GSWHIIV4YrTJTT6PNty5REojHJuZHArkF9VnHTERWoTjAzfI3kP+5b4alUdhgAZ7
# ttOu1bVnXfHaqPYl2rPs20ji03LOVWsh/radgE17es5hL+t6lV0eVHrVhsssROWJ
# uz2MXMCt7iw7lFPG9LXKGjsmonn2gotGdHIuEg5JnJMJVmixd5LRlkmgYRZKzhxS
# CwyoGIq0PhaA7Y+VPct5pCHkijcIIDm0nlkK+0KyepolcqGm0T/GYQRMhHJlGOOm
# VQop36wUVUYklUy++vDWeEgEo4s7hxN6mIbf2MSIQ/iIfMZgJxC69oukMUXCrOC3
# SkE/xIkgpfl22MM1itkZ35nNXkMolU1lAgMBAAGjggFOMIIBSjAOBgNVHQ8BAf8E
# BAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFH9ZP1Qh2q1P7wXl5qPX
# LQaUEggxMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAUci06AjGQQ7kUBU7h6qfHMdEjiTQwWgYDVR0fBFMwUTBP
# oE2gS4ZJaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljUm9vQ2VyQXV0MjAxMV8yMDExXzAzXzIyLmNybDBeBggrBgEFBQcBAQRSMFAw
# TgYIKwYBBQUHMAKGQmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMv
# TWljUm9vQ2VyQXV0MjAxMV8yMDExXzAzXzIyLmNydDANBgkqhkiG9w0BAQwFAAOC
# AgEAFJQfOChP7onn6fLIMKrSlN1WYKwDFgAddymOUO3FrM8d7B/W/iQ6DxXsDn7D
# 5W4wMwYeLystcEqfkjz4NURRgazyMu5yRzQh4LqjA4tStTcJh1opExo7nn5PuPBY
# nbu0+THSuVHTe0VTTPVhily/piFrDo3axQ9P4C+Ol5yet+2gTfekICS5xS+cYfSI
# vgn0JksVBVMYVI5QFu/qhnLhsEFEUzG8fvv0hjgkO+lkpV9ty6GkN4vdnd7ya6Q6
# aR9y34aiM1qmxaxBi6OUnyNl6fkuun/diTFnYDLTppOkr/mg5WSfCiDVMNCxtj4w
# PKC5OmHm1DQIt/MNokbbH3UGsFP1QbzsLocuSqLCvH09Io3fDPTmscR9Y75G4qX7
# RTX8AdBPo0I6OEojf39zuFZt0qOHm65YWQE69cZM2ueE1MB05dNNgHK9gTE7zKvK
# /fg8B2qjW88MT/WF5V5uvZGtqa9FSL2RazArA+rDPuf6JGYz4HpgMZHB4S6szWSK
# YBv0VisCzfxgeU+dquXW9bd0auYlOB58DPcOYKdc3Se94g+xL4pcEhbB54JOgAkw
# YTu/9dLeH2pDqeJZAABVDWRQCaXfO5LgyKwKCLYXpigrZYCjUSBcr+Ve8PFWMhVT
# Ql0v4q8J/AUmQN5W4n101cY2L4A7GTQG1h32HHAvfQESWP0xghncMIIZ2AIBATBu
# MFcxCzAJBgNVBAYTAlVTMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# KDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMjQCEzMAAAIc
# +s3Fm+gvfsQAAAAAAhwwDQYJYIZIAWUDBAIBBQCggZAwGQYJKoZIhvcNAQkDMQwG
# CisGAQQBgjcCAQQwLwYJKoZIhvcNAQkEMSIEIJd9vmTP52uwsFZ3hnkEnWstT10x
# C5QLAZqA25OgK89pMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8AcwBv
# AGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAE
# ggEAwCJYbDOpoq5Va5gOhBF4s6aK4O6BqXzA+BK8z88XwhclvrU3XFo32orrn0Lo
# 64GKQAQPl6UM6Sq9aJI24Nt57DcGjJ69+6QLIGFC1bl9R/Kd5Zcqx0MwfJvSoRTu
# xHuYQHDONIIbctrgkiUXJqnuV4zJwvmSDxp9xoOy3BwPAx5CvrkhqZJiWEcnPs1/
# ac3jk8P97sVMMdpSnUwUXm6bY09S5yH2jAP3bR7oRlxVxh87sO2EQRC892xvqWgg
# RgCKoj0X5l9NGew0JT3A/Aw8/vJjgTu27X6/vpZ3taaNwu/2FcMiWp7uzlemfpb/
# gFaNw2dQx1jzul2+Gi5a+Wk0EaGCF6wwgheoBgorBgEEAYI3AwMBMYIXmDCCF5QG
# CSqGSIb3DQEHAqCCF4UwgheBAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFZBgsqhkiG
# 9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQC
# AQUABCD7sOfZ92F3RUPuw6SBrxNN8rJFL8N+QISwSQ+dL4pPWAIGaq0qixRMGBIy
# MDI2MTAxMzAyNDIyNC40M1owBIACAfSggdmkgdYwgdMxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5k
# IE9wZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjZC
# MDUtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIR+zCCBygwggUQoAMCAQICEzMAAAIRRRg5m0PP/GwAAQAAAhEwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjUwODE0
# MTg0ODEzWhcNMjYxMTEzMTg0ODEzWjCB0zELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0
# aW9ucyBMaW1pdGVkMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046NkIwNS0wNUUw
# LUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIi
# MA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDPubszEB0vlVrKuTuOwyjcaeE3
# zmS0cJkS8RyPgEhxwcp380oLu4++lfl2E7rdbpUzmILGSUbypB5VWs9oq+Px1hgk
# LsM23g03deVV0L++i94m48+FMn+7tf6liZXap6FNU844HX+Gma3nVLODFlzMx2cW
# X5fZ7U+C61IDkICH39fPk1bQLGdhXPyDRWnGD4GrfZqaS1FevybcFISBSzyOBZE9
# XM8cRzOluGWgYYR8dpE6YeFUoio34mEzB4SNTY1czZbqGbfaP9Af8j8pao019hyE
# dobTEmWNVNihQo+lxAO6Ef11AoSC8bGPZTn/cWrV6bh07oiHTibpH623GvpjyhEk
# f1mFnexyIUEi9mHsTZgVc6M/gwbJtLKVBM8MQUC0ceCmSyR4RSGw8NH1W9ZaF6SF
# DHepdoAqH4CQubP+GkTd7TL5Ego7YBESNQskAqB/5H1Cc2+ox4yTP08auOyKOpYb
# MHaTYk3JpRgqVuZDB45puwKKiJjZ8luKaNXIUAaTkB5h11QXG8kaBFUIfsF4E8oC
# rsww6ZIJM4xnRLDrPI3HhSGHljS4nRk6hMqcHcp9039tr94ocV4SGLdaoB/NPGLL
# Ssy+Gx+xdkrvOhyWppG9WXxDjwnXvj57KuLKlj0eFT6iGCJiLi5AYMNV1MN4oO2g
# L+EPYKf4BHPATWsV8QIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFGJ9RQPA6eohy99v
# nf7JXQRmfs5wMB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1Ud
# HwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3Js
# L01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggr
# BgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIw
# MTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgw
# DgYDVR0PAQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4ICAQCkQp2cx4ghSJTo9q1n
# +puvCIPNhQwpFzMLgGn9djVL02Ycj7Zzd1ynAfZI6YN928giq3uZGuC8E9g68n0K
# 1lLl54iuw5sLRvSCApO/bCtOBYb6qS2o0USFB6Kl1RE0s3ry4cCbl53AHK13WTDL
# mvoH3eSXEOyV06ZVa3D+eCPuSc3T2a4KbCvXsmewwVygg38fn2z7VFg3tWJ3j7ue
# PwVy9jL2ttk4yd0HOxOKiwXUz5owglfaTcRUVWy4Mvv9Hmmkj1ODt5ZA5Yoxkc92
# wDdmpbMO6EmpPOgVJBKGdl6cL7Gr/P0GEc8UVtS1+MCgboQM+NJAlheaiCNrw4Rr
# X3HCeHfBW594/5yT7/SDE2LuD6Q7pZo6bTnYXiyIPzGLpS/vkvvv3yUe89OFzEce
# yBeoxjn3Z3XBSh/e0v94NpDRSGdgJTzIaRTZcmdy042cEoC9REC9/aqIhYOPguly
# bTMDtW6h+4lHVOm7JzmnWNrnZs1kEFWoA7DIOECapawlcCNheeywL98mR57fXgWH
# 4YjIyC8A9FJyCpFmpXXp1MFi+h77DWf/Baz/JJNSzEPDhP8AhNy7k8CwucJWkCsO
# sUtFMXK6354dSgbpRhl+Pz9Gy5DjYg2x7Wlv9w+bsbaVwsm2QgpPzTG8HUuJo289
# MFURyY1K8VQzTGtdldxhzFVeJjCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkA
# AAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUA
# A4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX
# 9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1q
# UoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8d
# q6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byN
# pOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2k
# rnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4d
# Pf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgS
# Uei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8
# QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6Cm
# gyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzF
# ER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQID
# AQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQU
# KqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1
# GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0
# dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0
# bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMA
# QTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbL
# j+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1p
# Y3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIz
# LmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwU
# tj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN
# 3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU
# 5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5
# KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGy
# qVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB6
# 2FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltE
# AY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFp
# AUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcd
# FYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRb
# atGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQd
# VTNYs6FwZvKhggNWMIICPgIBATCCAQGhgdmkgdYwgdMxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5k
# IE9wZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjZC
# MDUtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloiMKAQEwBwYFKw4DAhoDFQArKnyrZV2ACrVUaTN3s9nBXrM1zaCBgzCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA
# 7nfzHTAiGA8yMDI2MTAxMzAwMDAyOVoYDzIwMjYxMDE0MDAwMDI5WjB0MDoGCisG
# AQQBhFkKBAExLDAqMAoCBQDud/MdAgEAMAcCAQACAlDmMAcCAQACAhIlMAoCBQDu
# eUSdAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMH
# oSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQELBQADggEBAJWiU3WcH9wFWPjm0f/P
# El5Jds9DZEPZiEqOyCHsf6s0Z9quYN7HdXG4EYdv2BbxG3kv91jjlazmdILIW45L
# WtXYMccbCUQyP7f5vvsCAZKKX7bfHe7NtM1iQd29+HmaO9L2dzaDMVCKbuTHIZPR
# uEYOuqiP908gAQZaaSR+f/nWomQ/PrmSKNIQQ3GM/51a7AFT341TeXAESgQ+mjPT
# bwqrFiGXKtgXQ8dCGBL0t6Bg+rSCkvR0NNeYGjKJ/h94eVT/EENIxcXgfSoaC/Af
# nzqADUiIy7f3UVi+Ahtt4aL94BfLDX7LoxmHW7LEl+8miQU1NoaTOrHFrCIRqd3/
# wlMxggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAIT
# MwAAAhFFGDmbQ8/8bAABAAACETANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcN
# AQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDEAiCcb+5nG/9vdB5d
# 4ZQcwZgUDJsd5nEfBky/d5KgszCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0E
# ICytM6ma74dOrVpcXC+WGMXynadQI00IRf85Ysc0Mya3MIGYMIGApH4wfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAIRRRg5m0PP/GwAAQAAAhEwIgQg
# PmmKEtpVlfPPGP7DpAjeXoga8ih4SSTxwu4zOX+zoEkwDQYJKoZIhvcNAQELBQAE
# ggIACxlnEIs0TqaaUDCq9ibcmDS2VzadqymZ6Dse8U2hf8QJSg/gdzdZcHuG/gGj
# XygAMqZ1EPnvKCvQSTF7Bi2XOurWkrzVIBHdwfU62B1oaiNGDDl0Bs4ujzkCUtAw
# nygigrKQsuFHbUIO7K5Ij7gAD2rWcQLE/5Piv9ujwPJgj0e847vMVDWDMVBtLYrv
# oUHZE1HeG+PQ3tJhNAmXSeMoTLa8pm5oNA1wBqPdB0yxmiVTd1y4nfu9WrQd7RkN
# myrZFiDHfZviUfl13IspVqLkfimXTMHOvNDNf3aV7PGJ0Hsh//6dvkrEKqn7om4d
# kc7VVlK8D+OvlEEcnKOiLHmXGjTXtubFYhTcQYKUgM+ITkqCh9CQxf3ytG4RXGoh
# 7Vjcjuqm4gYx62YTIYeCj0qdYHcEuWTOsKz8vVp4WzOn4cwS4IOCWoSf7JmrS4qd
# /jqsq54D2YhATeeeYk4qjdiwwXxow2RTTfxBWqGPdctjnbqtmEnF/buYjJ0Ys+Ge
# /+zWzNnAynJ1FdmeqL5YDjOMFlT+bRtDbXN4qIHggsZR3V0sXRe5LJAGgQBtjHqD
# 8m4DBgyNwnA94JWIDCceChwcAvbUNkYkQqkOWnIKxJF0uZW2mZsor3p0a/1zukjr
# UDuloPY6y4uPeM80UzKKoThbMcdXktmqIgRqGHl83rh8eCI=
# SIG # End Windows Authenticode signature block