# azcloudhsm_logs_validation_utilities

## Release File Structure

A published release is laid out as follows:

```text
Utilities/                                                 # Published release location
└── AzureCloudHSM-AuditLogUtils-x.y.z.zip/                 # Versioned bundle root: x=major, y=minor, z=patch
    ├── README.md                                          # Install, usage, workflow, and troubleshooting
    ├── LICENSE.md                                         # Distribution license terms
    ├── VERSION                                            # Authoritative bundle version: x=major, y=minor, z=patch
    ├── azcloudhsm_logs_binary_to_text_windows_x64.exe     # Windows x64 binary-to-text converter
    ├── AzCloudHSM-Logs-Binary-To-Text-x.y.z-Linux-x64.deb # Debian/Ubuntu package for the Linux converter
    ├── AzCloudHSM-Logs-Binary-To-Text-x.y.z-Linux-x64.rpm # RHEL/Azure Linux package for the Linux converter
    └── azcloudhsm_logs_validation_utilities/              # Named Python package; install or run in place
        ├── pyproject.toml                                 # Package metadata, dependencies, and entry point
        ├── requirements.txt                               # Run-in-place dependencies
        ├── __init__.py                                    # Package marker and version export
        ├── azcloudhsm_logs_validation_cli.py              # CLI entry point and subcommand dispatcher
        ├── constants.py                                   # Version resolution and shared constants
        ├── tracer.py                                      # Runtime logging support
        └── commands/                                      # CLI subcommand modules
            ├── __init__.py                                # Command package marker
            ├── compare_hsm_logs.py                        # Compares converted logs with expected Log Analytics logs
            ├── get_signed_hsm_logs_batch.py               # Builds .bin, .sign, and certificate files
            └── verify_hsm_logs_signature.py               # Verifies the RSA-SHA256 batch signature
```

## Commands

`azcloudhsm_logs_validation_utilities` is a Python CLI tool for processing and verifying the cryptographic integrity of Azure Cloud HSM audit logs. It provides three commands:

1.  **get-signed-audit-log-batch** — The logs are retrieved from each HSM partition in batches, with each batch cryptographically signed by the HSM using the partition certificate key. All log records within a batch share the same `CorrelationId`. In addition to the text-based information, each individual log entry contains its corresponding binary data segment from the complete HSM-signed binary batch. This command concatenates the binary segments associated with individual logs from a given batch to reconstruct the original signed binary exactly as it was retrieved from the HSM (`.bin`). It also provides the signature for the HSM-signed batch (`.sign`) and the HSM public certificates (`_certs.json`), which can be used to verify the authenticity and integrity of the binary batch.
2.  **verify-audit-logs-signature** — Validates the RSA signature of the binary audit log batch using the Partition and HSM certificates extracted from the HSM, to ensure logs have not been tampered with.
3.  **compare-hsm-audit-logs** — Proves that the audit logs you retrieve from Log Analytics are complete and unaltered: it pairs that export, record by record, against the records that the binary to text converter extracts from the signature-verified `.bin` batch file, and reports any record or field that was dropped, added, or modified along the way.

## Prerequisites

-   Python 3.8 or higher.
-   `pip` for installing Python dependencies.

On Linux, the binary to text converter is distributed as installable `.deb` and `.rpm` packages. See [Install the Linux Converter](#install-the-linux-converter) to choose between them.

### Install Python and pip

Check whether a suitable version is already installed by running the commands under [Verify Python and pip](#verify-python-and-pip) below. If they report Python 3.8 or higher, skip the rest of this section. Otherwise install Python using the instructions for your platform. Modern Python installers include `pip`.

#### Windows

Install with `winget`:

```powershell
winget install --id Python.Python.3.14 --source winget
```

This installs the current stable release. Any version from 3.8 onwards works, so substitute a different minor version, such as `Python.Python.3.12`, if your environment standardizes on one.

Alternatively, download the installer from [python.org/downloads](https://www.python.org/downloads/) and select **Add python.exe to PATH** on the first screen of the installer. Close and reopen your terminal afterwards so the updated `PATH` takes effect.

#### Ubuntu

```bash
sudo apt update
sudo apt install -y python3 python3-pip
```

Ubuntu 20.04, 22.04, and 24.04 ship Python 3.8, 3.10, and 3.12 respectively, all of which satisfy the requirement.

#### RHEL 9

RHEL 9 ships Python 3.9 as the system `python3`:

```bash
sudo dnf install -y python3 python3-pip
```

#### RHEL 8

RHEL 8 defaults to Python 3.6, which is below the required 3.8. Install a newer module stream alongside it, then use `python3.9` and `pip3.9` in place of `python3` and `pip3`:

```bash
sudo dnf install -y python39 python39-pip
```

#### RHEL 7

RHEL 7 does not provide Python 3.8 in its base repositories. Install it from Software Collections, which leaves the system Python untouched:

```bash
sudo subscription-manager repos --enable rhel-server-rhscl-7-rpms
sudo yum install -y rh-python38
```

Activate the collection before using the tool. This puts a 3.8 `python` and `pip` on your `PATH`:

```bash
scl enable rh-python38 bash
python --version
pip --version
```

The `scl` command and `pip` are installed automatically as dependencies of `rh-python38`.

#### Azure Linux and CBL-Mariner 2

```bash
sudo tdnf install -y python3 python3-pip
```

#### Verify Python and pip

On Windows:

```powershell
python --version
pip --version
```

On Linux:

```bash
python3 --version
pip3 --version
```

If Python is installed but `pip` is missing, bootstrap it.

On Windows:

```powershell
python -m ensurepip --upgrade
```

On RHEL and Azure Linux:

```bash
python3 -m ensurepip --upgrade
```

On Ubuntu, `ensurepip` is disabled for the system Python, so install the packaged pip instead:

```bash
sudo apt install -y python3-pip
```

> **Note:** On Linux, run the examples in this README with `python3` and `pip3`. On Windows, use `python` and `pip`.

## Setup

Run the following from the `azcloudhsm_logs_validation_utilities/` directory of the unzipped bundle.

Install dependencies.

On Windows:

```powershell
pip install -r ./requirements.txt
```

On Linux:

```bash
pip3 install -r ./requirements.txt
```

## Get Audit Logs from Log Analytics

Azure Cloud HSM audit records are delivered to a Log Analytics workspace in the `CloudHsmHardwareOperationAuditLogs` table. Export the logs from that table to a file with either Azure PowerShell or the Azure CLI, then pass the file to `get-signed-audit-log-batch` (`-f`) and `compare-hsm-audit-logs` (`-e`).

In the examples below, replace the `<resource-group>`, `<workspace-name>`, `<subscription-id>`, and `<hsm-name>` placeholders with the values for the Cloud HSM resource and Log Analytics workspace that receive your audit logs.

### Log Analytics Prerequisites

-   Permission to read the workspace, such as the **Log Analytics Reader** role.
-   Either Azure PowerShell with the `Az.OperationalInsights` module:

    ```powershell
    Install-Module -Name Az.OperationalInsights -Scope CurrentUser
    Connect-AzAccount
    ```

-   Or the Azure CLI:

    ```bash
    az login
    ```

### Export File Encoding

The tool reads the export as UTF-8 and tolerates a leading byte order mark (BOM), but it cannot read a UTF-16 file. The PowerShell examples below use `Set-Content`, which writes UTF-8; on Linux, the shell's `>` operator writes the bytes unchanged.

On Windows PowerShell 5.1, do not substitute the `>` operator, which writes UTF-16. `Out-File -Encoding utf8` and `Set-Content -Encoding utf8` add a BOM, which is accepted.

### Download logs from the last seven days for a resource

Replace the placeholders with the values for your Cloud HSM resource and Log Analytics workspace. The query identifies batches that have records from the last seven days, and then exports every record for those batches so they remain complete. The `_ResourceId` filter is case-insensitive.

#### Azure CLI

##### Windows PowerShell

```powershell
$resourceGroupName = "<resource-group>"
$workspaceName     = "<workspace-name>"
$resourceId        = "/subscriptions/<subscription-id>/resourceGroups/<resource-group>/providers/Microsoft.HardwareSecurityModules/cloudHsmClusters/<hsm-name>"
$outputFile        = ".\logs\CloudHsmOperationLogsLast7Days.json"

New-Item -ItemType Directory -Force -Path ".\logs" | Out-Null

$workspaceCustomerId = az monitor log-analytics workspace show `
  --resource-group $resourceGroupName `
  --workspace-name $workspaceName `
  --query customerId `
  --output tsv

$query = @"
let recentBatches =
    CloudHsmHardwareOperationAuditLogs
    | where TimeGenerated >= ago(7d)
    | where _ResourceId =~ "$resourceId"
    | distinct CorrelationId;
CloudHsmHardwareOperationAuditLogs
| where _ResourceId =~ "$resourceId"
| where CorrelationId in (recentBatches)
"@

az monitor log-analytics query `
  --workspace $workspaceCustomerId `
  --analytics-query $query `
  --output json | Set-Content -Path $outputFile
```

##### Linux Bash Shell

```bash
resourceGroupName="<resource-group>"
workspaceName="<workspace-name>"
resourceId="/subscriptions/<subscription-id>/resourceGroups/<resource-group>/providers/Microsoft.HardwareSecurityModules/cloudHsmClusters/<hsm-name>"
outputFile="./logs/CloudHsmOperationLogsLast7Days.json"

mkdir -p ./logs

workspaceCustomerId=$(az monitor log-analytics workspace show \
  --resource-group "$resourceGroupName" \
  --workspace-name "$workspaceName" \
  --query customerId \
  --output tsv)

query=$(cat <<EOF
let recentBatches =
    CloudHsmHardwareOperationAuditLogs
    | where TimeGenerated >= ago(7d)
    | where _ResourceId =~ "$resourceId"
    | distinct CorrelationId;
CloudHsmHardwareOperationAuditLogs
| where _ResourceId =~ "$resourceId"
| where CorrelationId in (recentBatches)
EOF
)

az monitor log-analytics query \
  --workspace "$workspaceCustomerId" \
  --analytics-query "$query" \
  --output json > "$outputFile"
```

#### Azure PowerShell

##### Windows PowerShell

```powershell
$resourceGroupName = "<resource-group>"
$workspaceName     = "<workspace-name>"
$resourceId        = "/subscriptions/<subscription-id>/resourceGroups/<resource-group>/providers/Microsoft.HardwareSecurityModules/cloudHsmClusters/<hsm-name>"
$outputFile        = ".\logs\CloudHsmOperationLogsLast7Days.json"
$query = @"
let recentBatches =
    CloudHsmHardwareOperationAuditLogs
    | where TimeGenerated >= ago(7d)
    | where _ResourceId =~ "$resourceId"
    | distinct CorrelationId;
CloudHsmHardwareOperationAuditLogs
| where _ResourceId =~ "$resourceId"
| where CorrelationId in (recentBatches)
"@

New-Item -ItemType Directory -Force -Path ".\logs" | Out-Null

$workspace = Get-AzOperationalInsightsWorkspace `
  -ResourceGroupName $resourceGroupName `
  -Name $workspaceName

$response = Invoke-AzOperationalInsightsQuery `
  -WorkspaceId $workspace.CustomerId `
  -Query $query

$response | ConvertTo-Json -Depth 10 | Set-Content -Path $outputFile -Encoding utf8
```

##### Linux PowerShell

```powershell
$resourceGroupName = "<resource-group>"
$workspaceName     = "<workspace-name>"
$resourceId        = "/subscriptions/<subscription-id>/resourceGroups/<resource-group>/providers/Microsoft.HardwareSecurityModules/cloudHsmClusters/<hsm-name>"
$outputFile        = "./logs/CloudHsmOperationLogsLast7Days.json"
$query = @"
let recentBatches =
    CloudHsmHardwareOperationAuditLogs
    | where TimeGenerated >= ago(7d)
    | where _ResourceId =~ "$resourceId"
    | distinct CorrelationId;
CloudHsmHardwareOperationAuditLogs
| where _ResourceId =~ "$resourceId"
| where CorrelationId in (recentBatches)
"@

New-Item -ItemType Directory -Force -Path "./logs" | Out-Null

$workspace = Get-AzOperationalInsightsWorkspace `
  -ResourceGroupName $resourceGroupName `
  -Name $workspaceName

$response = Invoke-AzOperationalInsightsQuery `
  -WorkspaceId $workspace.CustomerId `
  -Query $query

$response | ConvertTo-Json -Depth 10 | Set-Content -Path $outputFile -Encoding utf8
```

---

### Download all logs for a given correlation ID

Use this query to download one complete signed batch. All records that have the specified `CorrelationId` are written to the output file, regardless of their order.

#### Azure CLI

##### Windows PowerShell

```powershell
$resourceGroupName = "<resource-group>"
$workspaceName     = "<workspace-name>"
$correlationId     = "<correlation-id>"
$outputFile        = ".\logs\CloudHsmOperationLogsByCorrelationId.json"

New-Item -ItemType Directory -Force -Path ".\logs" | Out-Null

$workspaceCustomerId = az monitor log-analytics workspace show `
  --resource-group $resourceGroupName `
  --workspace-name $workspaceName `
  --query customerId `
  --output tsv

$query = @"
CloudHsmHardwareOperationAuditLogs
| where CorrelationId == "$correlationId"
"@

az monitor log-analytics query `
  --workspace $workspaceCustomerId `
  --analytics-query $query `
  --output json | Set-Content -Path $outputFile
```

##### Linux Bash Shell

```bash
resourceGroupName="<resource-group>"
workspaceName="<workspace-name>"
correlationId="<correlation-id>"
outputFile="./logs/CloudHsmOperationLogsByCorrelationId.json"

mkdir -p ./logs

workspaceCustomerId=$(az monitor log-analytics workspace show \
  --resource-group "$resourceGroupName" \
  --workspace-name "$workspaceName" \
  --query customerId \
  --output tsv)

query=$(cat <<EOF
CloudHsmHardwareOperationAuditLogs
| where CorrelationId == "$correlationId"
EOF
)

az monitor log-analytics query \
  --workspace "$workspaceCustomerId" \
  --analytics-query "$query" \
  --output json > "$outputFile"
```

#### Azure PowerShell

##### Windows PowerShell

```powershell
$resourceGroupName = "<resource-group>"
$workspaceName     = "<workspace-name>"
$correlationId     = "<correlation-id>"
$outputFile        = ".\logs\CloudHsmOperationLogsByCorrelationId.json"
$query = @"
CloudHsmHardwareOperationAuditLogs
| where CorrelationId == "$correlationId"
"@

New-Item -ItemType Directory -Force -Path ".\logs" | Out-Null

$workspace = Get-AzOperationalInsightsWorkspace `
  -ResourceGroupName $resourceGroupName `
  -Name $workspaceName

$response = Invoke-AzOperationalInsightsQuery `
  -WorkspaceId $workspace.CustomerId `
  -Query $query

$response | ConvertTo-Json -Depth 10 | Set-Content -Path $outputFile -Encoding utf8
```

##### Linux PowerShell

```powershell
$resourceGroupName = "<resource-group>"
$workspaceName     = "<workspace-name>"
$correlationId     = "<correlation-id>"
$outputFile        = "./logs/CloudHsmOperationLogsByCorrelationId.json"
$query = @"
CloudHsmHardwareOperationAuditLogs
| where CorrelationId == "$correlationId"
"@

New-Item -ItemType Directory -Force -Path "./logs" | Out-Null

$workspace = Get-AzOperationalInsightsWorkspace `
  -ResourceGroupName $resourceGroupName `
  -Name $workspaceName

$response = Invoke-AzOperationalInsightsQuery `
  -WorkspaceId $workspace.CustomerId `
  -Query $query

$response | ConvertTo-Json -Depth 10 | Set-Content -Path $outputFile -Encoding utf8
```

---

### Narrow the Exported Batch

A signed batch can only be rebuilt if the export contains **every** record for a correlation id, including the signature record and the `BATCH_PARTITION_IDENTITY_CERT` and `BATCH_HSM_OWNER_AUTH_CERT` records.

-   Do not add `take` or `limit` to the query. They truncate the batch and cause `get-signed-audit-log-batch` to fail with a missing-record error.
-   To export a single batch, filter on the correlation id instead:

    ```kusto
    CloudHsmHardwareOperationAuditLogs
    | where CorrelationId == "0b59217c-3daf-11f1-94de-dbbd9f8f4603"
    ```

-   Row order does not matter. The tool reorders records by sequence number before building the `.bin` file.

## Usage

```bash
python ./azcloudhsm_logs_validation_cli.py [--debug] <command> [options]
```

To see available commands:

```bash
python ./azcloudhsm_logs_validation_cli.py --help
```

The optional `--debug` flag enables debug logging and echoes the parsed command-line arguments.

---

### Command: `get-signed-audit-log-batch`

Gets the signed binary audit log batch by combining the individual audit log binary records. For each processed correlation id, it produces a `.bin` file containing the combined audit log records, a `.sign` file containing the signature, drop count, and hash, and a `_certs.json` file containing the Partition and HSM certificates extracted from the audit log.

```bash
python ./azcloudhsm_logs_validation_cli.py get-signed-audit-log-batch -f <audit_log_file> [-v <correlation_id>]
```

#### Options

| Flag | Long Flag | Description | Required |
| :--- | :--- | :--- | :--- |
| `-f` | `--audit-log-file` | Path to the HSM operation schema file. | Yes |
| `-v` | `--correlation-id` | Correlation id for the batch of audit logs. If not provided, processes all correlation ids found in the file. | No |
| `-h` | `--help` | Display help for command. | No |

#### Output

The command produces three files per correlation id in a `binary_audit_files/` directory **under the current working directory**:

-   `audit_logs_<correlation_id>.bin` — Binary audit log entries (each entry is 128 bytes).
-   `audit_logs_<correlation_id>.sign` — 296-byte signature file: RSA signature (256 bytes) + drop count (8 bytes) + SHA-256 hash (32 bytes).
-   `audit_logs_<correlation_id>_certs.json` — JSON document containing the base64-encoded DER Partition and HSM Owner Auth certificates extracted from the audit log records.

#### Example

```bash
python ./azcloudhsm_logs_validation_cli.py get-signed-audit-log-batch \
  -f "./logs/SampleAuditLogs.log" \
  -v "0b59217c-3daf-11f1-94de-dbbd9f8f4603"
```

---

### Command: `verify-audit-logs-signature`

Verifies the RSA signature of Azure Cloud HSM audit logs given the `.bin`, `.sign`, and `_certs.json` files produced by `get-signed-audit-log-batch`.

```bash
python ./azcloudhsm_logs_validation_cli.py verify-audit-logs-signature -b <binary_file> -s <signature_file> -c <cert_file>
```

#### Options

| Flag | Long Flag | Description | Required |
| :--- | :--- | :--- | :--- |
| `-b` | `--binary-file` | Path to the binary file containing audit logs. | Yes |
| `-s` | `--signature-file` | Path to the signature file containing signature, drop count, and hash. | Yes |
| `-c` | `--cert-file` | Path to the certificates JSON file containing the Partition and HSM certificates. | Yes |
| `-h` | `--help` | Display help for command. | No |

#### Verification Process

The signature is an RSA-SHA256 signature by the Partition certificate over the SHA-256 hash of the following concatenated data:

| Binary Logs | HASH(PCertPub)\* | HASH(HCertPub)\* | droppedLogCount |
| :--- | :--- | :--- | :--- |
| 128 bytes × numLogs | 8 bytes | 8 bytes | 8 bytes |

\* `HASH(PCertPub)` and `HASH(HCertPub)` are the first 8 bytes of the SHA-1 hash of the DER-encoded SubjectPublicKeyInfo of the Partition/HSM certificate.

#### Example

```bash
python ./azcloudhsm_logs_validation_cli.py verify-audit-logs-signature \
  -b "./binary_audit_files/audit_logs_0b59217c-3daf-11f1-94de-dbbd9f8f4603.bin" \
  -s "./binary_audit_files/audit_logs_0b59217c-3daf-11f1-94de-dbbd9f8f4603.sign" \
  -c "./binary_audit_files/audit_logs_0b59217c-3daf-11f1-94de-dbbd9f8f4603_certs.json"
```

---

### Command: `compare-hsm-audit-logs`

Compares the Log Analytics audit log export (**expected**, `-e`) with the binary to text output (**actual**, `-a`) to confirm the logs Azure published match the logs the HSM signed. Produce the actual side first with [Convert Audit Logs to Text](#convert-audit-logs-to-text).

```bash
python ./azcloudhsm_logs_validation_cli.py compare-hsm-audit-logs -e <expected_log_file> -a <actual_log_file> -v <correlation_id>
```

#### Options

| Flag | Long Flag | Description | Required |
| :--- | :--- | :--- | :--- |
| `-e` | `--expected-log-file` | Path to the Log Analytics JSON export, either a JSON object with a top-level `Results` array or a top-level array of records. | Yes |
| `-a` | `--actual-log-file` | Path to the binary to text output, which holds one JSON record per line. | Yes |
| `-v` | `--correlation-id` | Correlation id identifying the audit log batch to compare. | Yes |
| `-h` | `--help` | Display help for command. | No |

Both file paths must refer to existing, non-empty files, and the correlation id must match the format `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`.

#### Comparison Process

1. Selects expected records whose `CorrelationId` matches the supplied value.
2. Excludes certificate and signature records, which are batch metadata rather than audit entries.
3. Pairs expected and actual records by sequence number.
4. Checks that both records carry every property the binary to text tool derives from the signed binary.
5. Compares the remaining properties, ignoring the columns Log Analytics adds that are not recoverable from the binary.

Findings are reported in four tables: actual records with no expected counterpart, expected records with no actual counterpart, required properties missing from either side, and property value differences.

A clean comparison exits with code `0`. Missing records, duplicate sequence numbers, missing required properties, property differences, invalid input, or no records for the correlation id produce a nonzero exit code.

#### Example

```bash
python ./azcloudhsm_logs_validation_cli.py compare-hsm-audit-logs \
  -e "./logs/LogAnalyticsAuditLogs.json" \
  -a "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.text.json" \
  -v "f166290a-9b5e-11f1-b617-0022486d4252"
```

## Logs

The tool writes execution logs to a `logs/` directory in the current working directory, including both success and error messages.

## Troubleshooting

-   **"File not found at path"**: Ensure all file paths provided are absolute or correctly relative to the current working directory.
-   **"Binary file size is not a multiple of 128 bytes"**: Ensure the correct `.bin` file (produced by `get-signed-audit-log-batch`) is provided.
-   **"Signature file size is not 296 bytes"**: Ensure the correct `.sign` file (produced by `get-signed-audit-log-batch`) is provided.
-   **"Partition certificate DER data is missing" / "HSM Owner Auth certificate DER data is missing"**: Ensure the correct `_certs.json` file (produced by `get-signed-audit-log-batch`) is provided and that it contains base64-encoded DER certificates.
-   **Signature Failure**:
    -   Ensure the `.bin`, `.sign`, and `_certs.json` files all correspond to the same correlation id and were produced from the same audit log.
    -   Ensure the log and binary files have not been modified manually.
-   **"codec can't decode byte"**: The export was saved as UTF-16. Re-export it as UTF-8, as described in [Export File Encoding](#export-file-encoding).
-   **"No audit log entries found for correlation id"**: Verify the correlation id value matches what appears in the audit log file's `CorrelationId` field.
-   **"Correlation id format is invalid"**: The correlation id must match the format `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`.

## Audit Log Binary to Text and Comparison

The Azure Cloud HSM audit log binary to text tool converts the binary audit log file produced by `get-signed-audit-log-batch` into human-readable JSON records. Each binary input record must be exactly 128 bytes.

The `compare-hsm-audit-logs` command then compares that output with the corresponding audit records exported from Log Analytics.

### Binary to Text Prerequisites

- A binary audit log file produced by `get-signed-audit-log-batch`.
- The audit log binary to text converter for your operating system:
  `azcloudhsm_logs_binary_to_text_windows_x64.exe` on Windows; on Linux, install
  either the `.deb` or the `.rpm` package as described in
  [Install the Linux Converter](#install-the-linux-converter).
- A Log Analytics JSON export, either a JSON object with a top-level `Results` array or a top-level array of records.

### Install the Linux Converter

On Linux the converter ships as a `.deb` and an `.rpm`. Both contain the same
executable and install it to `/opt/azurecloudhsm_auditlogutils/bin/`. The path
does not change between releases, so installing a newer package upgrades the
existing installation in place. Use the package that matches your distribution:

| Package | Use this when |
| --- | --- |
| `.rpm` | You are on RHEL 7, 8, or 9, or Azure Linux / CBL-Mariner 2 |
| `.deb` | You are on Ubuntu 20.04, 22.04, or 24.04 |

If you are unsure which format your distribution uses, check which package manager is present:

```bash
command -v rpm  && echo "use the .rpm"
command -v dpkg && echo "use the .deb"
```

#### RHEL and Azure Linux (`.rpm`)

```bash
sudo rpm -i AzCloudHSM-Logs-Binary-To-Text-x.y.z-Linux-x64.rpm
```

To upgrade an existing installation, use `sudo rpm -U` in place of `sudo rpm -i`.

#### Ubuntu (`.deb`)

```bash
sudo dpkg -i AzCloudHSM-Logs-Binary-To-Text-x.y.z-Linux-x64.deb
```

Installing a newer package over an older one upgrades it in place.

#### Verify

```bash
/opt/azurecloudhsm_auditlogutils/bin/azcloudhsm_logs_binary_to_text_linux_x64 --version
```

To run the converter without typing the full path, add its directory to your `PATH`:

```bash
export PATH="/opt/azurecloudhsm_auditlogutils/bin:$PATH"
```

#### Uninstall

```bash
sudo rpm -e AzCloudHSM-Logs-Binary-To-Text    # RHEL and Azure Linux
sudo dpkg -r AzCloudHSM-Logs-Binary-To-Text   # Ubuntu
```

### Convert Audit Logs to Text

#### Binary to Text Syntax

```text
<binary-to-text-executable> -f <path> -o <path>
```

| Option | Short option | Description | Required |
| --- | --- | --- | --- |
| `--binary-file` | `-f` | Path to the `.bin` file produced by `get-signed-audit-log-batch`. | Yes |
| `--output-file` | `-o` | Path to the text output file. The file is overwritten if it exists. | Yes |
| `--version` | | Display the tool version and exit. | No |
| `--help` | `-h` | Display command help. | No |

To check the tool version:

##### Windows

```powershell
.\azcloudhsm_logs_binary_to_text_windows_x64.exe --version
```

##### Linux

```bash
/opt/azurecloudhsm_auditlogutils/bin/azcloudhsm_logs_binary_to_text_linux_x64 --version
```

#### Binary to Text Example

##### Windows

Run this command from the directory containing `azcloudhsm_logs_binary_to_text_windows_x64.exe`:

```powershell
.\azcloudhsm_logs_binary_to_text_windows_x64.exe `
  -f ".\binary_audit_files\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin" `
  -o ".\binary_audit_files\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.text.json"
```

##### Linux

Run this command after installing the `.deb` or `.rpm` package:

```bash
/opt/azurecloudhsm_auditlogutils/bin/azcloudhsm_logs_binary_to_text_linux_x64 \
  -f "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin" \
  -o "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.text.json"
```

The tool validates the input file and writes the converted audit records to the requested output file. A successful run exits with code `0`; failures return a nonzero exit code.

### Compare Expected and Actual Logs

See [Command: `compare-hsm-audit-logs`](#command-compare-hsm-audit-logs) for the syntax, options, and comparison process.

### Binary to Text End-to-End Example

See [End-to-End Workflow](#end-to-end-workflow) for the full sequence, which covers conversion and comparison as steps 4 and 5.

### Binary to Text Troubleshooting

- **Input size is not a multiple of 128 bytes:** Use the `.bin` file generated by `get-signed-audit-log-batch` and confirm it has not been truncated or modified.
- **Invalid JSON structure:** The Log Analytics export is neither a JSON object with a top-level `Results` array nor a top-level array of records. Re-export using `Invoke-AzOperationalInsightsQuery` or `az monitor log-analytics query` without reshaping the result.
- **No expected audit logs found:** The export parsed correctly but carries no non-metadata record for the supplied correlation id. Confirm the correlation id is correct and that ingestion has completed.
- **Duplicate expected audit log found:** More than one non-metadata record has the same sequence number for the selected correlation id. Confirm that the export does not contain duplicate rows.
- **Duplicate actual audit logs:** The converted output holds more than one record with the same sequence number. The first record for that sequence number is compared and the repeats are listed in this table. Confirm the binary to text output was not concatenated from overlapping batches.
- **Actual audit logs missing from expected audit logs:** Confirm that the Log Analytics export includes the complete batch and that ingestion has completed.
- **Required properties missing from the audit logs:** One side does not carry a property the binary to text tool derives from the signed binary. Confirm both files come from the same batch and that neither has been edited.

## End-to-End Workflow

This walkthrough runs every command in order: export the audit logs, rebuild the HSM-signed batch, verify its signature, convert the batch to readable records, and confirm those records match the Log Analytics export.

The examples use the correlation id `f166290a-9b5e-11f1-b617-0022486d4252`. Replace it with a `CorrelationId` from your own audit log. Run the Python commands from the `azcloudhsm_logs_validation_utilities/` directory.

### Windows

1.  **Export the audit logs** from Log Analytics to `.\logs\LogAnalyticsAuditLogs.json`, using [Download logs from the last seven days for a resource](#download-logs-from-the-last-seven-days-for-a-resource) or [Download all logs for a given correlation ID](#download-all-logs-for-a-given-correlation-id).

2.  **Build the signed batch** for the correlation id:

    ```powershell
    python .\azcloudhsm_logs_validation_cli.py get-signed-audit-log-batch `
      -f ".\logs\LogAnalyticsAuditLogs.json" `
      -v "f166290a-9b5e-11f1-b617-0022486d4252"
    ```

    Output:

    ```text
    [2026-10-12T20:29:36.783391+00:00] get-signed-audit-log-batch version: 1.0.0
    [2026-10-12T20:29:36.783555+00:00] Parsed arguments: {
     "auditLogFile": ".\\logs\\LogAnalyticsAuditLogs.json",
     "correlationId": "f166290a-9b5e-11f1-b617-0022486d4252"
    }
    [2026-10-12T20:29:36.783763+00:00] Parsing audit logs for correlation id: f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:29:36.787364+00:00] Found signature record for correlation id f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:29:36.787447+00:00] Decoded signature buffer length: 264 bytes for correlation id f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:29:36.787647+00:00] Decoded hash buffer length: 32 bytes for correlation id f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:29:36.787718+00:00] Found HSM certificate record for correlation id f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:29:36.787764+00:00] Found partition certificate record for correlation id f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:29:36.788081+00:00] Total lines read from audit log file: 203
    [2026-10-12T20:29:36.789174+00:00] Saved binary data to file at path: C:\audit\binary_audit_files\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin
    [2026-10-12T20:29:36.789219+00:00] Successfully saved binary audit logs to file: audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin
    [2026-10-12T20:29:36.790706+00:00] Saved binary data to file at path: C:\audit\binary_audit_files\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.sign
    [2026-10-12T20:29:36.790760+00:00] Successfully saved binary signature to file: audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.sign
    [2026-10-12T20:29:36.791572+00:00] Successfully saved certificates to file: C:\audit\binary_audit_files\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252_certs.json
    [2026-10-12T20:29:36.791618+00:00] Closing logger
    [2026-10-12T20:29:36.791640+00:00]
     Log file saved to: C:\audit\logs\get-signed-audit-log-batch_2026-10-12T20-29-36-782875+00-00.log
    ```

    This writes the `.bin`, `.sign`, and `_certs.json` files to `.\binary_audit_files\`. Omit `-v` to process every correlation id in the export.

3.  **Verify the signature** of the batch:

    ```powershell
    python .\azcloudhsm_logs_validation_cli.py verify-audit-logs-signature `
      -b ".\binary_audit_files\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin" `
      -s ".\binary_audit_files\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.sign" `
      -c ".\binary_audit_files\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252_certs.json"
    ```

    Output:

    ```text
    [2026-10-12T20:29:52.480411+00:00] verify-audit-logs-signature version: 1.0.0
    [2026-10-12T20:29:52.480805+00:00] Parsed arguments: {
     "binaryFile": ".\\binary_audit_files\\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin",
     "signatureFile": ".\\binary_audit_files\\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.sign",
     "certFile": ".\\binary_audit_files\\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252_certs.json"
    }
    [2026-10-12T20:29:52.497782+00:00] Drop count from signature file: 0
    [2026-10-12T20:29:52.498607+00:00] Success: Hash of the concatenated data matches the hash included in the signature file.
    [2026-10-12T20:29:52.500177+00:00] Success: Signature verification succeeded. The audit logs are authentic and have not been tampered with.
    [2026-10-12T20:29:52.500243+00:00] Audit logs signature verification completed.
    [2026-10-12T20:29:52.500273+00:00]
     Log file saved to: C:\audit\logs\verify-audit-logs-signature_2026-10-12T20-29-52-479182+00-00.log
    ```

4.  **Convert the binary batch to text.** Run this from the directory containing `azcloudhsm_logs_binary_to_text_windows_x64.exe`:

    ```powershell
    .\azcloudhsm_logs_binary_to_text_windows_x64.exe `
      -f ".\binary_audit_files\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin" `
      -o ".\binary_audit_files\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.text.json"
    ```

    Output:

    ```text
    Total records in '.\binary_audit_files\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin': 3
    Converted record 1/3 (sequence number: 0X000000000000002C)
    Converted record 2/3 (sequence number: 0X000000000000002D)
    Converted record 3/3 (sequence number: 0X000000000000002E)
    ```

5.  **Compare** the converted records with the Log Analytics export:

    ```powershell
    python .\azcloudhsm_logs_validation_cli.py compare-hsm-audit-logs `
      -e ".\logs\LogAnalyticsAuditLogs.json" `
      -a ".\binary_audit_files\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.text.json" `
      -v "f166290a-9b5e-11f1-b617-0022486d4252"
    ```

    Output:

    ```text
    [2026-10-12T20:29:52.923982+00:00] compare-hsm-audit-logs version: 1.0.0
    [2026-10-12T20:29:52.924150+00:00] Parsed arguments: {
     "expectedLogFile": ".\\logs\\LogAnalyticsAuditLogs.json",
     "actualLogFile": ".\\binary_audit_files\\audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.text.json",
     "correlationId": "f166290a-9b5e-11f1-b617-0022486d4252"
    }
    [2026-10-12T20:29:52.928846+00:00] All 3 expected audit log(s) match the actual audit logs for CorrelationId: f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:29:52.928923+00:00]
     Log file saved to: C:\audit\logs\compare-hsm-audit-logs_2026-10-12T20-29-52-923224+00-00.log
    ```

### Linux

1.  **Export the audit logs** from Log Analytics to `./logs/LogAnalyticsAuditLogs.json`, using [Download logs from the last seven days for a resource](#download-logs-from-the-last-seven-days-for-a-resource) or [Download all logs for a given correlation ID](#download-all-logs-for-a-given-correlation-id).

2.  **Build the signed batch** for the correlation id:

    ```bash
    python3 ./azcloudhsm_logs_validation_cli.py get-signed-audit-log-batch \
      -f "./logs/LogAnalyticsAuditLogs.json" \
      -v "f166290a-9b5e-11f1-b617-0022486d4252"
    ```

    Output:

    ```text
    [2026-10-12T20:28:48.403186+00:00] get-signed-audit-log-batch version: 1.0.0
    [2026-10-12T20:28:48.403294+00:00] Parsed arguments: {
     "auditLogFile": "./logs/LogAnalyticsAuditLogs.json",
     "correlationId": "f166290a-9b5e-11f1-b617-0022486d4252"
    }
    [2026-10-12T20:28:48.403336+00:00] Parsing audit logs for correlation id: f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:28:48.407480+00:00] Found signature record for correlation id f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:28:48.407562+00:00] Decoded signature buffer length: 264 bytes for correlation id f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:28:48.407575+00:00] Decoded hash buffer length: 32 bytes for correlation id f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:28:48.407588+00:00] Found HSM certificate record for correlation id f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:28:48.407612+00:00] Found partition certificate record for correlation id f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:28:48.407744+00:00] Total lines read from audit log file: 203
    [2026-10-12T20:28:48.408374+00:00] Saved binary data to file at path: /tmp/audit/binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin
    [2026-10-12T20:28:48.408414+00:00] Successfully saved binary audit logs to file: audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin
    [2026-10-12T20:28:48.408506+00:00] Saved binary data to file at path: /tmp/audit/binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.sign
    [2026-10-12T20:28:48.408539+00:00] Successfully saved binary signature to file: audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.sign
    [2026-10-12T20:28:48.408689+00:00] Successfully saved certificates to file: /tmp/audit/binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252_certs.json
    [2026-10-12T20:28:48.408728+00:00] Closing logger
    [2026-10-12T20:28:48.408738+00:00]
     Log file saved to: /tmp/audit/logs/get-signed-audit-log-batch_2026-10-12T20-28-48-403097+00-00.log
    ```

    This writes the `.bin`, `.sign`, and `_certs.json` files to `./binary_audit_files/`. Omit `-v` to process every correlation id in the export.

3.  **Verify the signature** of the batch:

    ```bash
    python3 ./azcloudhsm_logs_validation_cli.py verify-audit-logs-signature \
      -b "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin" \
      -s "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.sign" \
      -c "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252_certs.json"
    ```

    Output:

    ```text
    [2026-10-12T20:28:48.509022+00:00] verify-audit-logs-signature version: 1.0.0
    [2026-10-12T20:28:48.509132+00:00] Parsed arguments: {
     "binaryFile": "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin",
     "signatureFile": "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.sign",
     "certFile": "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252_certs.json"
    }
    [2026-10-12T20:28:48.511468+00:00] Drop count from signature file: 0
    [2026-10-12T20:28:48.511848+00:00] Success: Hash of the concatenated data matches the hash included in the signature file.
    [2026-10-12T20:28:48.512663+00:00] Success: Signature verification succeeded. The audit logs are authentic and have not been tampered with.
    [2026-10-12T20:28:48.512720+00:00] Audit logs signature verification completed.
    [2026-10-12T20:28:48.512736+00:00]
     Log file saved to: /tmp/audit/logs/verify-audit-logs-signature_2026-10-12T20-28-48-508915+00-00.log
    ```

4.  **Convert the binary batch to text** using the installed converter:

    ```bash
    /opt/azurecloudhsm_auditlogutils/bin/azcloudhsm_logs_binary_to_text_linux_x64 \
      -f "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin" \
      -o "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.text.json"
    ```

    Output:

    ```text
    Total records in './binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.bin': 3
    Converted record 1/3 (sequence number: 0X000000000000002C)
    Converted record 2/3 (sequence number: 0X000000000000002D)
    Converted record 3/3 (sequence number: 0X000000000000002E)
    ```

5.  **Compare** the converted records with the Log Analytics export:

    ```bash
    python3 ./azcloudhsm_logs_validation_cli.py compare-hsm-audit-logs \
      -e "./logs/LogAnalyticsAuditLogs.json" \
      -a "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.text.json" \
      -v "f166290a-9b5e-11f1-b617-0022486d4252"
    ```

    Output:

    ```text
    [2026-10-12T20:29:25.141139+00:00] compare-hsm-audit-logs version: 1.0.0
    [2026-10-12T20:29:25.141242+00:00] Parsed arguments: {
     "expectedLogFile": "./logs/LogAnalyticsAuditLogs.json",
     "actualLogFile": "./binary_audit_files/audit_logs_f166290a-9b5e-11f1-b617-0022486d4252.text.json",
     "correlationId": "f166290a-9b5e-11f1-b617-0022486d4252"
    }
    [2026-10-12T20:29:25.143998+00:00] All 3 expected audit log(s) match the actual audit logs for CorrelationId: f166290a-9b5e-11f1-b617-0022486d4252
    [2026-10-12T20:29:25.144062+00:00]
     Log file saved to: /tmp/audit/logs/compare-hsm-audit-logs_2026-10-12T20-29-25-141045+00-00.log
    ```

Steps 3 and 5 exit with code `0` when the signature is valid and the records match. Any other exit code indicates a failure; see [Troubleshooting](#troubleshooting).
